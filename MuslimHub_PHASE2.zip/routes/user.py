from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, abort
from flask_login import login_required, current_user
from models import User, Friendship, PrivateMessage, Notification, Memorial
from app_init import db
from datetime import datetime

user_bp = Blueprint('user', __name__)

from constants import AVATARS
def valid_avatar(avatar: str) -> str:
    avatar = (avatar or '').strip()
    return avatar if avatar in AVATARS else AVATARS[0]


@user_bp.route('/<username>')
def profile(username):
    user = User.query.filter_by(username=username).first_or_404()
    if user.is_banned:
        abort(404)

    can_view = True
    friendship = None

    if user.privacy == 'private' and (not current_user.is_authenticated or current_user.id != user.id):
        can_view = False
    elif user.privacy == 'friends':
        if not current_user.is_authenticated or (current_user.id != user.id and not current_user.is_friends_with(user)):
            can_view = False

    if current_user.is_authenticated and current_user.id != user.id:
        friendship = current_user.friendship_with(user)

    memorials = []
    if can_view or (current_user.is_authenticated and current_user.id == user.id):
        memorials = Memorial.query.filter_by(user_id=user.id, is_public=True).limit(5).all()

    return render_template(
        'user/profile.html',
        profile_user=user,
        can_view=can_view,
        friendship=friendship,
        memorials=memorials
    )


@user_bp.route('/edit', methods=['GET', 'POST'])
@login_required
def edit_profile():
    if request.method == 'POST':
        current_user.display_name = (request.form.get('display_name', '').strip() or current_user.username)[:80]
        current_user.bio = (request.form.get('bio', '').strip())[:300]
        current_user.avatar = valid_avatar(request.form.get('avatar', current_user.avatar))
        privacy = request.form.get('privacy', 'public')
        current_user.privacy = privacy if privacy in {'public', 'friends', 'private'} else 'public'

        db.session.commit()
        flash('تم تحديث الملف الشخصي ✓', 'success')
        return redirect(url_for('user.profile', username=current_user.username))

    return render_template('user/edit_profile.html', avatars=AVATARS)


@user_bp.route('/friends/send/<int:uid>', methods=['POST'])
@login_required
def send_friend_request(uid):
    if uid == current_user.id:
        return jsonify({'ok': False, 'msg': 'لا يمكنك إضافة نفسك'})
    target = User.query.get_or_404(uid)
    existing = current_user.friendship_with(target)
    if existing:
        return jsonify({'ok': False, 'msg': 'طلب موجود بالفعل'})
    f = Friendship(requester_id=current_user.id, addressee_id=uid)
    db.session.add(f)
    n = Notification(
        user_id=uid,
        type='friend_request',
        message=f'{current_user.get_name()} أرسل إليك طلب صداقة',
        link=url_for('user.profile', username=current_user.username)
    )
    db.session.add(n)
    db.session.commit()
    return jsonify({'ok': True, 'msg': 'تم إرسال طلب الصداقة'})


@user_bp.route('/friends/accept/<int:uid>', methods=['POST'])
@login_required
def accept_friend(uid):
    f = Friendship.query.filter_by(requester_id=uid, addressee_id=current_user.id, status='pending').first_or_404()
    f.status = 'accepted'
    db.session.commit()
    n = Notification(
        user_id=uid,
        type='friend_accepted',
        message=f'{current_user.get_name()} قبل طلب صداقتك 💚',
        link=url_for('user.profile', username=current_user.username)
    )
    db.session.add(n)
    db.session.commit()
    flash('تمت قبول طلب الصداقة', 'success')
    return redirect(url_for('user.friends'))


@user_bp.route('/friends/reject/<int:uid>', methods=['POST'])
@login_required
def reject_friend(uid):
    f = Friendship.query.filter(
        db.or_(
            db.and_(Friendship.requester_id == uid, Friendship.addressee_id == current_user.id),
            db.and_(Friendship.requester_id == current_user.id, Friendship.addressee_id == uid)
        )
    ).first_or_404()
    db.session.delete(f)
    db.session.commit()
    flash('تم رفض الطلب', 'info')
    return redirect(url_for('user.friends'))


@user_bp.route('/friends/block/<int:uid>', methods=['POST'])
@login_required
def block_user(uid):
    existing = current_user.friendship_with(User.query.get_or_404(uid))
    if existing:
        existing.status = 'blocked'
        if existing.requester_id != current_user.id:
            existing.requester_id, existing.addressee_id = current_user.id, uid
    else:
        db.session.add(Friendship(requester_id=current_user.id, addressee_id=uid, status='blocked'))
    db.session.commit()
    flash('تم الحظر', 'info')
    nxt = request.referrer; return redirect(nxt if nxt and nxt.startswith('/') else url_for('main.index'))


@user_bp.route('/friends/unfriend/<int:uid>', methods=['POST'])
@login_required
def unfriend(uid):
    target = User.query.get_or_404(uid)
    f = current_user.friendship_with(target)
    if f:
        db.session.delete(f)
        db.session.commit()
    flash('تم إلغاء الصداقة', 'info')
    nxt = request.referrer; return redirect(nxt if nxt and nxt.startswith('/') else url_for('user.friends'))


@user_bp.route('/friends')
@login_required
def friends():
    accepted = [f for f in current_user.sent_requests.filter_by(status='accepted').all()] + \
               [f for f in current_user.received_requests.filter_by(status='accepted').all()]
    pending_in = current_user.received_requests.filter_by(status='pending').all()
    pending_out = current_user.sent_requests.filter_by(status='pending').all()
    return render_template('user/friends.html', accepted=accepted, pending_in=pending_in, pending_out=pending_out)


@user_bp.route('/messages')
@login_required
def messages():
    sent = db.session.query(PrivateMessage.receiver_id).filter_by(sender_id=current_user.id).distinct()
    received = db.session.query(PrivateMessage.sender_id).filter_by(receiver_id=current_user.id).distinct()
    partner_ids = set([r[0] for r in sent] + [r[0] for r in received])

    partners = []
    for pid in partner_ids:
        u = User.query.get(pid)
        if u:
            last_msg = PrivateMessage.query.filter(
                db.or_(
                    db.and_(PrivateMessage.sender_id == current_user.id, PrivateMessage.receiver_id == pid),
                    db.and_(PrivateMessage.sender_id == pid, PrivateMessage.receiver_id == current_user.id)
                )
            ).order_by(PrivateMessage.created_at.desc()).first()

            unread = PrivateMessage.query.filter_by(sender_id=pid, receiver_id=current_user.id, is_read=False).count()
            partners.append({'user': u, 'last_msg': last_msg, 'unread': unread})

    partners.sort(key=lambda x: x['last_msg'].created_at if x['last_msg'] else datetime.min, reverse=True)
    return render_template('user/messages.html', partners=partners)


@user_bp.route('/messages/<username>', methods=['GET', 'POST'])
@login_required
def conversation(username):
    partner = User.query.filter_by(username=username).first_or_404()
    if partner.id == current_user.id:
        return redirect(url_for('user.messages'))

    if request.method == 'POST':
        body = request.form.get('body', '').strip()[:1000]
        if body:
            msg = PrivateMessage(sender_id=current_user.id, receiver_id=partner.id, body=body)
            db.session.add(msg)
            n = Notification(
                user_id=partner.id,
                type='message',
                message=f'رسالة جديدة من {current_user.get_name()}',
                link=url_for('user.conversation', username=current_user.username)
            )
            db.session.add(n)
            db.session.commit()
        return redirect(url_for('user.conversation', username=username))

    PrivateMessage.query.filter_by(sender_id=partner.id, receiver_id=current_user.id, is_read=False).update({'is_read': True})
    db.session.commit()

    msgs = PrivateMessage.query.filter(
        db.or_(
            db.and_(PrivateMessage.sender_id == current_user.id, PrivateMessage.receiver_id == partner.id),
            db.and_(PrivateMessage.sender_id == partner.id, PrivateMessage.receiver_id == current_user.id)
        )
    ).order_by(PrivateMessage.created_at.asc()).all()

    return render_template('user/conversation.html', partner=partner, msgs=msgs)


@user_bp.route('/notifications')
@login_required
def notifications():
    notifs = current_user.notifications.order_by(Notification.created_at.desc()).limit(50).all()
    Notification.query.filter_by(user_id=current_user.id, is_read=False).update({'is_read': True})
    db.session.commit()
    return render_template('user/notifications.html', notifs=notifs)


@user_bp.route('/search')
def search_users():
    q = request.args.get('q', '').strip()
    users = []
    if q and len(q) >= 2:
        users = User.query.filter(
            db.or_(User.username.ilike(f'%{q}%'), User.display_name.ilike(f'%{q}%')),
            User.is_banned == False,
            User.is_active == True
        ).limit(20).all()
    return render_template('user/search.html', users=users, q=q)


@user_bp.route('/stats')
def stats():
    return render_template('user/stats.html')