from flask import Blueprint, render_template

prayer_bp = Blueprint('prayer', __name__)

@prayer_bp.route('/')
def index():
    return render_template('prayer/index.html')
