from flask import Blueprint, render_template, request, jsonify, session

quran_bp = Blueprint('quran', __name__)

@quran_bp.route('/')
def index():
    return render_template('quran/index.html')

@quran_bp.route('/<int:surah_num>')
def surah(surah_num):
    from models import Reciter
    reciters = Reciter.query.filter_by(is_active=True).order_by(Reciter.order_num).all()
    return render_template('quran/surah.html', surah_num=surah_num, reciters=reciters)
