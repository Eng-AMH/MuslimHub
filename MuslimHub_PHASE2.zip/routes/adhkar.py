from flask import Blueprint, render_template
from models import Dhikr
from constants import ADHKAR_CATEGORIES

adhkar_bp = Blueprint('adhkar', __name__)

CATEGORIES = ADHKAR_CATEGORIES   # backward-compat alias


@adhkar_bp.route('/')
def index():
    return render_template('adhkar/index.html', categories=CATEGORIES)


@adhkar_bp.route('/morning')
def morning():
    items = Dhikr.query.filter_by(category='morning').order_by(Dhikr.order_num).all()
    return render_template('adhkar/morning_evening.html',
        items=items, category='morning',
        title='أذكار الصباح', subtitle='ابدأ يومك بذكر الله', icon='🌅')


@adhkar_bp.route('/evening')
def evening():
    items = Dhikr.query.filter_by(category='evening').order_by(Dhikr.order_num).all()
    return render_template('adhkar/morning_evening.html',
        items=items, category='evening',
        title='أذكار المساء', subtitle='اختم يومك بذكر الله', icon='🌇')


@adhkar_bp.route('/<category>')
def category(category):
    if category == 'morning':
        return morning()
    if category == 'evening':
        return evening()
    items    = Dhikr.query.filter_by(category=category).order_by(Dhikr.order_num).all()
    cat_info = CATEGORIES.get(category, {'ar': category, 'en': category, 'icon': '📿'})
    return render_template('adhkar/category.html',
        items=items, category=category, cat_info=cat_info, categories=CATEGORIES)
