from functools import lru_cache
from flask import Blueprint, render_template, session, request, redirect, url_for
from models import Duaa, Dhikr, FeaturedContent
from app_init import db
from constants import VALID_THEMES
import json, os
from datetime import date

main_bp = Blueprint('main', __name__)

# ── Cached JSON loaders (reads file once per process lifetime) ────────────────

@lru_cache(maxsize=1)
def _load_good_deeds():
    data_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data', 'good_deeds.json')
    if os.path.exists(data_path):
        with open(data_path, encoding='utf-8') as f:
            return json.load(f)
    return []


@main_bp.route('/')
def index():
    featured = FeaturedContent.query.filter_by(is_active=True).order_by(FeaturedContent.id.desc()).first()
    featured_duaa = None if featured else Duaa.query.filter_by(is_featured=True).first()

    good_deeds = _load_good_deeds()
    daily_deed = None
    if good_deeds:
        daily_deed = good_deeds[date.today().timetuple().tm_yday % len(good_deeds)]

    return render_template('index.html',
        featured=featured,
        featured_duaa=featured_duaa,
        daily_deed=daily_deed,
    )


@main_bp.route('/set-lang/<lang>')
def set_lang(lang):
    if lang in ['ar', 'en']:
        session['lang'] = lang
    return redirect(request.referrer or url_for('main.index'))


@main_bp.route('/set-theme/<theme>')
def set_theme(theme):
    if theme in VALID_THEMES:
        session['theme'] = theme
    return redirect(request.referrer or url_for('main.index'))


@main_bp.route('/favorites')
def favorites():
    return render_template('favorites/index.html')


@main_bp.route('/settings')
def settings():
    return render_template('settings.html')


@main_bp.route('/about')
def about():
    return render_template('about.html')


@main_bp.route('/contact')
def contact():
    return render_template('contact.html')


@main_bp.route('/privacy')
def privacy():
    return render_template('privacy.html')


@main_bp.route('/terms')
def terms():
    return render_template('terms.html')


@main_bp.route('/good-deeds-page')
def good_deeds_page():
    return render_template('good_deeds/index.html', deeds=_load_good_deeds())


@main_bp.route('/dismiss-salawat', methods=['POST'])
def dismiss_salawat():
    from flask import jsonify
    session['salawat_dismissed'] = True
    return jsonify({'ok': True})
