from flask import Blueprint, render_template

tasbeeh_bp = Blueprint('tasbeeh', __name__)

@tasbeeh_bp.route('/')
def index():
    return render_template('tasbeeh/index.html')
