from flask import Blueprint, render_template, request, redirect, url_for, session
from flask_login import current_user
from models import Memorial
from app_init import db
import uuid

memorial_bp = Blueprint('memorial', __name__)


@memorial_bp.route('/', methods=['GET', 'POST'])
def index():
    if 'session_id' not in session:
        session['session_id'] = str(uuid.uuid4())

    if request.method == 'POST':
        name           = request.form.get('name', '').strip()[:200]
        note           = request.form.get('note', '').strip()[:1000]          # length-limited
        preferred_duaa = request.form.get('preferred_duaa', '').strip()[:500] # length-limited

        if name:
            entry = Memorial(
                name           = name,
                note           = note,
                preferred_duaa = preferred_duaa,
                session_id     = session['session_id'],
                # Associate with logged-in user so entries survive session expiry
                user_id        = current_user.id if current_user.is_authenticated else None,
            )
            db.session.add(entry)
            db.session.commit()

        return redirect(url_for('memorial.index'))

    # Show entries belonging to this session (or the logged-in user)
    if current_user.is_authenticated:
        entries = Memorial.query.filter(
            db.or_(
                Memorial.user_id    == current_user.id,
                Memorial.session_id == session['session_id'],
            )
        ).order_by(Memorial.created_at.desc()).all()
    else:
        entries = Memorial.query.filter_by(
            session_id=session['session_id']
        ).order_by(Memorial.created_at.desc()).all()

    return render_template('memorial/index.html', entries=entries)


@memorial_bp.route('/delete/<int:entry_id>', methods=['POST'])
def delete(entry_id):
    entry = Memorial.query.get_or_404(entry_id)
    owns  = (entry.session_id == session.get('session_id'))
    if current_user.is_authenticated and entry.user_id == current_user.id:
        owns = True
    if owns:
        db.session.delete(entry)
        db.session.commit()
    return redirect(url_for('memorial.index'))
