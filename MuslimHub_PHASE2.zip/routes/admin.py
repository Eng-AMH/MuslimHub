from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from functools import wraps
from models import Admin, Duaa, Dhikr, Memorial, ChatMessage, AuditLog, FeaturedContent, SiteSettings
from app_init import db
from flask_wtf.csrf import validate_csrf, ValidationError
from datetime import datetime
import re

admin_bp = Blueprint('admin', __name__)

# CDN key format — must match quran-audio.js CDN_KEY_RE exactly
_CDN_KEY_RE = re.compile(r'^[a-zA-Z][a-zA-Z0-9._-]{1,99}$')
_SUPPORTED_CDN_KEYS = {
    'ar.alafasy',
    'ar.abdurrahmaansudais',
    'ar.mahermuaiqly',
    'ar.shaatree',
    'ar.saadalghamdi',
    'ar.abdulbasitmurattal',
    'ar.husary',
    'ar.minshawi',
    'ar.ahmedajamy',
    'ar.hanirifai',
    'ar.hudhaify',
    'ar.abdullahbasfar',
    'ar.husarymujawwad',
    'ar.abdulbasitmujawwad',
}


def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('admin_logged_in'):
            return redirect(url_for('admin.login'))
        return f(*args, **kwargs)
    return decorated


def _safe_int(value, default=0):
    """Convert form value to int with safe fallback."""
    try:
        return int(value or default)
    except (ValueError, TypeError):
        return default


def _validate_admin_csrf():
    """Validate CSRF token from admin form POST. Raises on failure."""
    try:
        validate_csrf(request.form.get('csrf_token'))
    except ValidationError:
        flash('طلب غير صالح — رمز الحماية CSRF مفقود أو منتهي الصلاحية', 'error')
        return False
    return True


def log_action(action, model='', record_id=None, details=''):
    log = AuditLog(
        admin_username=session.get('admin_username', 'unknown'),
        action=action, model=model,
        record_id=record_id, details=details,
    )
    db.session.add(log)
    db.session.commit()


# ── Auth ──────────────────────────────────────────────────────────────────────
@admin_bp.route('/login', methods=['GET', 'POST'])
def login():
    if session.get('admin_logged_in'):
        return redirect(url_for('admin.dashboard'))
    error = None
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        admin    = Admin.query.filter_by(username=username).first()
        if admin and admin.check_password(password):
            session['admin_logged_in'] = True
            session['admin_username']  = admin.username
            session['admin_role']      = admin.role
            admin.last_login = datetime.utcnow()
            db.session.commit()
            return redirect(url_for('admin.dashboard'))
        error = 'بيانات الدخول غير صحيحة'
    return render_template('admin/login.html', error=error)


@admin_bp.route('/logout')
def logout():
    session.pop('admin_logged_in', None)
    session.pop('admin_username',  None)
    session.pop('admin_role',      None)
    return redirect(url_for('admin.login'))


# ── Dashboard ─────────────────────────────────────────────────────────────────
@admin_bp.route('/')
@admin_required
def dashboard():
    from models import User, Hadith
    stats = {
        'users':     User.query.count(),
        'duas':      Duaa.query.count(),
        'adhkar':    Dhikr.query.count(),
        'hadiths':   Hadith.query.count(),
        'memorials': Memorial.query.count(),
        'messages':  ChatMessage.query.count(),
    }
    recent_logs = AuditLog.query.order_by(AuditLog.timestamp.desc()).limit(10).all()
    return render_template('admin/dashboard.html', stats=stats, recent_logs=recent_logs)


# ── Duas CRUD ─────────────────────────────────────────────────────────────────
@admin_bp.route('/duas')
@admin_required
def duas():
    items = Duaa.query.order_by(Duaa.category, Duaa.order_num).all()
    return render_template('admin/duas.html', items=items)


@admin_bp.route('/duas/add', methods=['GET', 'POST'])
@admin_required
def duas_add():
    if request.method == 'POST':
        if not _validate_admin_csrf():
            return redirect(url_for('admin.duas_add'))
        d = Duaa(
            title_ar             = request.form.get('title_ar', ''),
            title_en             = request.form.get('title_en', ''),
            text_ar              = request.form.get('text_ar', ''),
            text_en              = request.form.get('text_en', ''),
            text_transliteration = request.form.get('text_transliteration', ''),
            category             = request.form.get('category', ''),
            source               = request.form.get('source', ''),
            is_featured          = bool(request.form.get('is_featured')),
            order_num            = _safe_int(request.form.get('order_num'), 0),
        )
        db.session.add(d)
        db.session.commit()
        log_action('إضافة دعاء', 'Duaa', d.id, d.title_ar)
        flash('تمت إضافة الدعاء بنجاح', 'success')
        return redirect(url_for('admin.duas'))
    return render_template('admin/duaa_form.html', item=None)


@admin_bp.route('/duas/edit/<int:id>', methods=['GET', 'POST'])
@admin_required
def duas_edit(id):
    d = Duaa.query.get_or_404(id)
    if request.method == 'POST':
        if not _validate_admin_csrf():
            return redirect(url_for('admin.duas_edit', id=id))
        d.title_ar             = request.form.get('title_ar', '')
        d.title_en             = request.form.get('title_en', '')
        d.text_ar              = request.form.get('text_ar', '')
        d.text_en              = request.form.get('text_en', '')
        d.text_transliteration = request.form.get('text_transliteration', '')
        d.category             = request.form.get('category', '')
        d.source               = request.form.get('source', '')
        d.is_featured          = bool(request.form.get('is_featured'))
        d.order_num            = _safe_int(request.form.get('order_num'), 0)
        db.session.commit()
        log_action('تعديل دعاء', 'Duaa', d.id, d.title_ar)
        flash('تم تعديل الدعاء بنجاح', 'success')
        return redirect(url_for('admin.duas'))
    return render_template('admin/duaa_form.html', item=d)


@admin_bp.route('/duas/delete/<int:id>', methods=['POST'])
@admin_required
def duas_delete(id):
    if not _validate_admin_csrf():
        return redirect(url_for('admin.duas'))
    d = Duaa.query.get_or_404(id)
    log_action('حذف دعاء', 'Duaa', d.id, d.title_ar)
    db.session.delete(d)
    db.session.commit()
    flash('تم حذف الدعاء', 'info')
    return redirect(url_for('admin.duas'))


# ── Adhkar CRUD ───────────────────────────────────────────────────────────────
@admin_bp.route('/adhkar')
@admin_required
def adhkar():
    items = Dhikr.query.order_by(Dhikr.category, Dhikr.order_num).all()
    return render_template('admin/adhkar.html', items=items)


@admin_bp.route('/adhkar/add', methods=['GET', 'POST'])
@admin_required
def adhkar_add():
    if request.method == 'POST':
        if not _validate_admin_csrf():
            return redirect(url_for('admin.adhkar_add'))
        d = Dhikr(
            title_ar             = request.form.get('title_ar', ''),
            title_en             = request.form.get('title_en', ''),
            text_ar              = request.form.get('text_ar', ''),
            text_en              = request.form.get('text_en', ''),
            text_transliteration = request.form.get('text_transliteration', ''),
            category             = request.form.get('category', ''),
            repetitions          = _safe_int(request.form.get('repetitions'), 1),
            source               = request.form.get('source', ''),
            order_num            = _safe_int(request.form.get('order_num'), 0),
        )
        db.session.add(d)
        db.session.commit()
        log_action('إضافة ذكر', 'Dhikr', d.id, d.title_ar)
        flash('تمت إضافة الذكر بنجاح', 'success')
        return redirect(url_for('admin.adhkar'))
    return render_template('admin/dhikr_form.html', item=None)


@admin_bp.route('/adhkar/edit/<int:id>', methods=['GET', 'POST'])
@admin_required
def adhkar_edit(id):
    d = Dhikr.query.get_or_404(id)
    if request.method == 'POST':
        if not _validate_admin_csrf():
            return redirect(url_for('admin.adhkar_edit', id=id))
        d.title_ar             = request.form.get('title_ar', '')
        d.title_en             = request.form.get('title_en', '')
        d.text_ar              = request.form.get('text_ar', '')
        d.text_en              = request.form.get('text_en', '')
        d.text_transliteration = request.form.get('text_transliteration', '')
        d.category             = request.form.get('category', '')
        d.repetitions          = _safe_int(request.form.get('repetitions'), 1)
        d.source               = request.form.get('source', '')
        d.order_num            = _safe_int(request.form.get('order_num'), 0)
        db.session.commit()
        log_action('تعديل ذكر', 'Dhikr', d.id, d.title_ar)
        flash('تم تعديل الذكر بنجاح', 'success')
        return redirect(url_for('admin.adhkar'))
    return render_template('admin/dhikr_form.html', item=d)


@admin_bp.route('/adhkar/delete/<int:id>', methods=['POST'])
@admin_required
def adhkar_delete(id):
    if not _validate_admin_csrf():
        return redirect(url_for('admin.adhkar'))
    d = Dhikr.query.get_or_404(id)
    log_action('حذف ذكر', 'Dhikr', d.id, d.title_ar)
    db.session.delete(d)
    db.session.commit()
    flash('تم حذف الذكر', 'info')
    return redirect(url_for('admin.adhkar'))


# ── Memorials ─────────────────────────────────────────────────────────────────
@admin_bp.route('/memorials')
@admin_required
def memorials():
    items = Memorial.query.order_by(Memorial.created_at.desc()).all()
    return render_template('admin/memorials.html', items=items)


@admin_bp.route('/memorials/delete/<int:id>', methods=['POST'])
@admin_required
def memorials_delete(id):
    if not _validate_admin_csrf():
        return redirect(url_for('admin.memorials'))
    m = Memorial.query.get_or_404(id)
    db.session.delete(m)
    db.session.commit()
    flash('تم الحذف', 'info')
    return redirect(url_for('admin.memorials'))


# ── Featured Content ──────────────────────────────────────────────────────────
@admin_bp.route('/featured', methods=['GET', 'POST'])
@admin_required
def featured():
    if request.method == 'POST':
        if not _validate_admin_csrf():
            return redirect(url_for('admin.featured'))
        fc = FeaturedContent(
            content_type = request.form.get('content_type', 'duaa'),
            content_ar   = request.form.get('content_ar', ''),
            content_en   = request.form.get('content_en', ''),
            source       = request.form.get('source', ''),
            is_active    = bool(request.form.get('is_active')),
        )
        db.session.add(fc)
        db.session.commit()
        flash('تمت الإضافة', 'success')
        return redirect(url_for('admin.featured'))
    items = FeaturedContent.query.order_by(FeaturedContent.id.desc()).all()
    return render_template('admin/featured.html', items=items)


# ── Audit Logs ────────────────────────────────────────────────────────────────
@admin_bp.route('/logs')
@admin_required
def logs():
    page  = request.args.get('page', 1, type=int)
    items = AuditLog.query.order_by(AuditLog.timestamp.desc()).paginate(page=page, per_page=50)
    return render_template('admin/logs.html', items=items)


# ── Chat messages ─────────────────────────────────────────────────────────────
@admin_bp.route('/chat-messages')
@admin_required
def chat_messages():
    msgs = ChatMessage.query.order_by(ChatMessage.timestamp.desc()).limit(200).all()
    return render_template('admin/chat_messages.html', msgs=msgs)


@admin_bp.route('/chat-messages/delete/<int:id>', methods=['POST'])
@admin_required
def chat_delete(id):
    if not _validate_admin_csrf():
        return redirect(url_for('admin.chat_messages'))
    m = ChatMessage.query.get_or_404(id)
    db.session.delete(m)
    db.session.commit()
    return redirect(url_for('admin.chat_messages'))


# ── User Management ───────────────────────────────────────────────────────────
@admin_bp.route('/users')
@admin_required
def users():
    page  = request.args.get('page', 1, type=int)
    q     = request.args.get('q', '')
    from models import User
    query = User.query
    if q:
        query = query.filter(
            User.username.ilike(f'%{q}%') |
            User.display_name.ilike(f'%{q}%') |
            User.email.ilike(f'%{q}%')
        )
    items = query.order_by(User.created_at.desc()).paginate(page=page, per_page=30)
    return render_template('admin/users.html', items=items, q=q)


@admin_bp.route('/users/ban/<int:uid>', methods=['POST'])
@admin_required
def ban_user(uid):
    if not _validate_admin_csrf():
        return redirect(url_for('admin.users'))
    from models import User
    u = User.query.get_or_404(uid)
    u.is_banned = not u.is_banned
    db.session.commit()
    log_action('حظر/رفع حظر مستخدم', 'User', uid, u.username)
    flash(f'{"تم حظر" if u.is_banned else "تم رفع حظر"} {u.username}', 'info')
    return redirect(url_for('admin.users'))


@admin_bp.route('/users/delete/<int:uid>', methods=['POST'])
@admin_required
def delete_user(uid):
    if not _validate_admin_csrf():
        return redirect(url_for('admin.users'))
    from models import User
    if session.get('admin_role') != 'super_admin':
        flash('هذا الإجراء متاح للمشرف الرئيسي فقط', 'error')
        return redirect(url_for('admin.users'))
    u = User.query.get_or_404(uid)
    log_action('حذف مستخدم', 'User', uid, u.username)
    db.session.delete(u)
    db.session.commit()
    flash(f'تم حذف {u.username}', 'info')
    return redirect(url_for('admin.users'))


# ── Reports ───────────────────────────────────────────────────────────────────
@admin_bp.route('/reports')
@admin_required
def reports():
    from models import Report
    items = Report.query.order_by(Report.created_at.desc()).limit(100).all()
    return render_template('admin/reports.html', items=items)


@admin_bp.route('/reports/resolve/<int:rid>', methods=['POST'])
@admin_required
def resolve_report(rid):
    if not _validate_admin_csrf():
        return redirect(url_for('admin.reports'))
    from models import Report
    r = Report.query.get_or_404(rid)
    r.status = 'resolved'
    db.session.commit()
    return redirect(url_for('admin.reports'))


# ── Reciters ──────────────────────────────────────────────────────────────────
@admin_bp.route('/reciters')
@admin_required
def reciters():
    from models import Reciter, AudioHealthCheck
    items = Reciter.query.order_by(Reciter.order_num).all()

    # Latest health check per reciter (small table, N+1 is fine here — this
    # is a low-traffic admin screen, not a hot path; keeps the query simple).
    latest_checks = {}
    for r in items:
        latest_checks[r.id] = (
            AudioHealthCheck.query
            .filter_by(reciter_id=r.id)
            .order_by(AudioHealthCheck.checked_at.desc())
            .first()
        )
    return render_template('admin/reciters.html', items=items, latest_checks=latest_checks)


@admin_bp.route('/reciters/test/<int:rid>', methods=['POST'])
@admin_required
def test_reciter(rid):
    """
    Admin-triggered live health check of a reciter's actual audio source.
    Mirrors the client engine's own bitrate fallback (services/audio_service.py)
    so this reports exactly what a real listener would experience — never
    reports a broken source as healthy just because *a* URL responded.
    """
    if not _validate_admin_csrf():
        return redirect(url_for('admin.reciters'))
    from models import Reciter, AudioHealthCheck
    from services.audio_service import check_reciter_audio

    r = Reciter.query.get_or_404(rid)
    result = check_reciter_audio(r.cdn_key, surah_num=1)

    check = AudioHealthCheck(
        reciter_id=r.id,
        surah_num=1,
        status=result['status'],
        bitrate=result['bitrate'],
        url=result['url'],
        http_status=result['http_status'],
        content_type=result['content_type'],
        latency_ms=result['latency_ms'],
        failure_reason=result['failure_reason'],
        checked_by=session.get('admin_username', 'unknown'),
    )
    db.session.add(check)
    log_action('اختبار صوت', 'Reciter', r.id, f"{r.name_ar} → {result['status']}")
    db.session.commit()

    flash_map = {
        'healthy': ('success', f'{r.name_ar}: يعمل بشكل ممتاز ({result["latency_ms"]}ms)'),
        'warning': ('warning', f'{r.name_ar}: يعمل، لكن {result["failure_reason"]}'),
        'broken':  ('error',   f'{r.name_ar}: لا يعمل — {result["failure_reason"]}'),
    }
    category, message = flash_map.get(result['status'], ('info', 'تم الاختبار'))
    flash(message, category)
    return redirect(url_for('admin.reciters'))


@admin_bp.route('/reciters/toggle/<int:rid>', methods=['POST'])
@admin_required
def toggle_reciter(rid):
    if not _validate_admin_csrf():
        return redirect(url_for('admin.reciters'))
    from models import Reciter
    r = Reciter.query.get_or_404(rid)
    r.is_active = not r.is_active
    db.session.commit()
    return redirect(url_for('admin.reciters'))


@admin_bp.route('/reciters/save', methods=['POST'])
@admin_required
def reciter_save():
    if not _validate_admin_csrf():
        return redirect(url_for('admin.reciters'))
    from models import Reciter
    rid     = request.form.get('id', '').strip()
    name_ar = request.form.get('name_ar', '').strip()
    cdn_key = request.form.get('cdn_key', '').strip()
    name_en = request.form.get('name_en', '').strip() or None
    style   = request.form.get('style', 'مرتل').strip()
    order   = _safe_int(request.form.get('order_num'), 0)

    # ── Field presence ──
    if not name_ar or not cdn_key:
        flash('الاسم العربي والـ CDN Key مطلوبان', 'error')
        return redirect(url_for('admin.reciters'))

    # ── CDN key validation ──
    # Must start with a letter; only letters, digits, dots, underscores, hyphens allowed.
    if not _CDN_KEY_RE.match(cdn_key):
        flash(
            'مفتاح CDN غير صالح. استخدم مفتاحاً بصيغة ar.* فقط.',
            'error'
        )
        return redirect(url_for('admin.reciters'))

    if cdn_key not in _SUPPORTED_CDN_KEYS:
        flash(
            'هذا القارئ غير مدعوم حالياً في النسخة المستقرة. استخدم أحد القرّاء المعتمدين فقط.',
            'error'
        )
        return redirect(url_for('admin.reciters'))

    # ── Duplicate CDN key check (different reciter) ──
    existing = Reciter.query.filter_by(cdn_key=cdn_key).first()
    current_rid = _safe_int(rid) if rid else None
    if existing and existing.id != current_rid:
        flash(
            f'مفتاح CDN "{cdn_key}" مستخدم بالفعل للقارئ "{existing.name_ar}". '
            'استخدم مفتاحاً مختلفاً أو عدّل القارئ الموجود.',
            'error'
        )
        return redirect(url_for('admin.reciters'))

    if rid and current_rid:
        r = Reciter.query.get(current_rid)
        if r:
            r.name_ar = name_ar; r.name_en = name_en; r.cdn_key = cdn_key
            r.style   = style;   r.order_num = order
            log_action('تعديل قارئ', 'Reciter', r.id, f'{name_ar} ({cdn_key})')
    else:
        new_r = Reciter(
            name_ar=name_ar, name_en=name_en, cdn_key=cdn_key,
            style=style, order_num=order,
        )
        db.session.add(new_r)
        db.session.flush()
        log_action('إضافة قارئ', 'Reciter', new_r.id, f'{name_ar} ({cdn_key})')

    db.session.commit()
    flash('تم حفظ القارئ', 'success')
    return redirect(url_for('admin.reciters'))


@admin_bp.route('/reciters/delete/<int:rid>', methods=['POST'])
@admin_required
def delete_reciter(rid):
    if not _validate_admin_csrf():
        return redirect(url_for('admin.reciters'))
    from models import Reciter
    r = Reciter.query.get_or_404(rid)
    db.session.delete(r)
    db.session.commit()
    flash('تم حذف القارئ', 'success')
    return redirect(url_for('admin.reciters'))


# ── Hadith CRUD ───────────────────────────────────────────────────────────────
@admin_bp.route('/hadiths')
@admin_required
def hadiths():
    from models import Hadith
    items = Hadith.query.order_by(Hadith.category, Hadith.order_num).all()
    return render_template('admin/hadiths.html', items=items)


@admin_bp.route('/hadiths/add', methods=['GET', 'POST'])
@admin_required
def hadiths_add():
    from models import Hadith
    if request.method == 'POST':
        if not _validate_admin_csrf():
            return redirect(url_for('admin.hadiths_add'))
        h = Hadith(
            text_ar    = request.form.get('text_ar', ''),
            text_en    = request.form.get('text_en', ''),
            narrator   = request.form.get('narrator', ''),
            source     = request.form.get('source', ''),
            grading    = request.form.get('grading', ''),
            category   = request.form.get('category', 'general'),
            is_featured = bool(request.form.get('is_featured')),
            order_num  = _safe_int(request.form.get('order_num'), 0),
        )
        db.session.add(h)
        db.session.commit()
        log_action('إضافة حديث', 'Hadith', h.id, h.source)
        flash('تمت إضافة الحديث', 'success')
        return redirect(url_for('admin.hadiths'))
    return render_template('admin/hadith_form.html', item=None)


@admin_bp.route('/hadiths/edit/<int:id>', methods=['GET', 'POST'])
@admin_required
def hadiths_edit(id):
    from models import Hadith
    h = Hadith.query.get_or_404(id)
    if request.method == 'POST':
        if not _validate_admin_csrf():
            return redirect(url_for('admin.hadiths_edit', id=id))
        h.text_ar    = request.form.get('text_ar', '')
        h.text_en    = request.form.get('text_en', '')
        h.narrator   = request.form.get('narrator', '')
        h.source     = request.form.get('source', '')
        h.grading    = request.form.get('grading', '')
        h.category   = request.form.get('category', 'general')
        h.is_featured = bool(request.form.get('is_featured'))
        h.order_num  = _safe_int(request.form.get('order_num'), 0)
        db.session.commit()
        log_action('تعديل حديث', 'Hadith', h.id, h.source)
        flash('تم تعديل الحديث', 'success')
        return redirect(url_for('admin.hadiths'))
    return render_template('admin/hadith_form.html', item=h)


@admin_bp.route('/hadiths/delete/<int:id>', methods=['POST'])
@admin_required
def hadiths_delete(id):
    if not _validate_admin_csrf():
        return redirect(url_for('admin.hadiths'))
    from models import Hadith
    h = Hadith.query.get_or_404(id)
    db.session.delete(h)
    db.session.commit()
    flash('تم الحذف', 'info')
    return redirect(url_for('admin.hadiths'))