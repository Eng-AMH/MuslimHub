from flask import Blueprint, render_template, request
from models import Hadith
from constants import HADITH_CATEGORIES
from datetime import date

hadith_bp = Blueprint('hadith', __name__)

CATEGORIES = HADITH_CATEGORIES   # backward-compat alias


@hadith_bp.route('/')
def index():
    category = request.args.get('category', '')
    search   = request.args.get('q', '')
    page     = request.args.get('page', 1, type=int)

    q = Hadith.query
    if category:
        q = q.filter_by(category=category)
    if search:
        q = q.filter(Hadith.text_ar.contains(search) | Hadith.text_en.contains(search))

    hadiths = q.order_by(Hadith.order_num, Hadith.id).paginate(
        page=page, per_page=30, error_out=False
    )

    # Hadith of the day
    all_featured = Hadith.query.filter_by(is_featured=True).all()
    daily = None
    if all_featured:
        daily = all_featured[date.today().timetuple().tm_yday % len(all_featured)]

    return render_template(
        'hadith/index.html',
        hadiths=hadiths,
        categories=CATEGORIES,
        current_category=category,
        search=search,
        daily=daily,
    )
