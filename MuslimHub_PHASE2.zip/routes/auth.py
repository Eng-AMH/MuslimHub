from urllib.parse import urlparse, urljoin

from flask import Blueprint, render_template, request, redirect, url_for, flash, current_app
from flask_login import login_user, logout_user, login_required, current_user

from models import User
from app_init import db
from constants import AVATARS
import re

auth_bp = Blueprint('auth', __name__)


def valid_username(u):
    return re.match(r'^[a-zA-Z0-9_]{3,40}$', u) is not None


def valid_avatar(avatar: str) -> str:
    avatar = (avatar or '').strip()
    return avatar if avatar in AVATARS else AVATARS[0]


def is_safe_url(target: str) -> bool:
    """Return True only when target stays on the same host."""
    ref_url  = urlparse(request.host_url)
    test_url = urlparse(urljoin(request.host_url, target))
    return (
        test_url.scheme in ('http', 'https')
        and ref_url.netloc == test_url.netloc
    )


@auth_bp.route('/signup', methods=['GET', 'POST'])
def signup():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))

    error = None

    if request.method == 'POST':
        username     = request.form.get('username', '').strip().lower()
        display_name = request.form.get('display_name', '').strip()
        email        = request.form.get('email', '').strip().lower()
        password     = request.form.get('password', '')
        confirm      = request.form.get('confirm', '')
        avatar       = valid_avatar(request.form.get('avatar', AVATARS[0]))

        if not valid_username(username):
            error = 'اسم المستخدم يجب أن يكون 3-40 حرف (أحرف، أرقام، _)'
        elif User.query.filter_by(username=username).first():
            error = 'اسم المستخدم مستخدم بالفعل'
        elif User.query.filter_by(email=email).first():
            error = 'البريد الإلكتروني مستخدم بالفعل'
        elif len(password) < 8:                              # raised from 6 → 8
            error = 'كلمة المرور يجب أن تكون 8 أحرف على الأقل'
        elif password != confirm:
            error = 'كلمتا المرور غير متطابقتين'
        else:
            user = User(
                username=username,
                display_name=display_name or username,
                email=email,
                avatar=avatar,
            )
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            login_user(user, remember=True)
            flash('مرحباً بك في Muslim Hub! 🌿', 'success')
            return redirect(url_for('main.index'))

    return render_template('auth/signup.html', error=error, avatars=AVATARS)


@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))

    error = None

    if request.method == 'POST':
        identifier = request.form.get('identifier', '').strip().lower()
        password   = request.form.get('password', '')
        remember   = bool(request.form.get('remember'))

        user = User.query.filter(
            db.or_(User.username == identifier, User.email == identifier)
        ).first()

        if not user or not user.check_password(password):
            error = 'بيانات الدخول غير صحيحة'
        elif user.is_banned:
            error = 'هذا الحساب موقوف. تواصل مع الإدارة.'
        else:
            login_user(user, remember=remember)

            # Safe redirect — validate the `next` param to prevent open redirect
            nxt = request.args.get('next')
            if not nxt or not is_safe_url(nxt):
                nxt = url_for('main.index')

            flash(f'أهلاً {user.get_name()} 🌿', 'success')
            return redirect(nxt)

    return render_template('auth/login.html', error=error)


@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash('تم تسجيل الخروج بنجاح', 'info')
    return redirect(url_for('main.index'))


@auth_bp.route('/change-password', methods=['GET', 'POST'])
@login_required
def change_password():
    error = None

    if request.method == 'POST':
        current_pw = request.form.get('current_password', '')
        new_pw     = request.form.get('new_password', '')
        confirm    = request.form.get('confirm', '')

        if not current_user.check_password(current_pw):
            error = 'كلمة المرور الحالية غير صحيحة'
        elif len(new_pw) < 8:                               # raised from 6 → 8
            error = 'كلمة المرور الجديدة يجب أن تكون 8 أحرف على الأقل'
        elif new_pw != confirm:
            error = 'كلمتا المرور غير متطابقتين'
        else:
            current_user.set_password(new_pw)
            db.session.commit()
            flash('تم تغيير كلمة المرور بنجاح', 'success')
            return redirect(url_for('user.profile', username=current_user.username))

    return render_template('auth/change_password.html', error=error)
