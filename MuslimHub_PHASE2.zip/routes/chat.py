from datetime import datetime

from flask import Blueprint, jsonify, render_template, request, session
from flask_login import current_user

from app_init import db
from models import ChatMessage

chat_bp = Blueprint('chat', __name__)

_SEND_COOLDOWN_SECS = 2   # minimum seconds between messages per user


def _clean_username(value: str, fallback: str = 'زائر') -> str:
    value = (value or '').strip()
    return value[:100] if value else fallback


def _clean_message(value: str) -> str:
    return (value or '').strip()[:500]


def _serialize_message(msg: ChatMessage, active_user_id=None):
    """Use user_id only for mine-detection — avoids display_name collision."""
    mine = (active_user_id is not None and msg.user_id == active_user_id)
    return {
        'id':        msg.id,
        'user_id':   msg.user_id,
        'username':  msg.username,
        'message':   msg.message,
        'type':      msg.message_type or 'text',
        'timestamp': msg.timestamp.strftime('%H:%M'),
        'room':      msg.room,
        'mine':      mine,
    }


@chat_bp.route('/')
def index():
    room     = request.args.get('room', 'general')
    messages = (
        ChatMessage.query
        .filter_by(room=room, is_deleted=False)
        .order_by(ChatMessage.id.asc())
        .limit(120)
        .all()
    )
    initial_username = ''
    if current_user.is_authenticated:
        initial_username = current_user.get_name() or current_user.username or ''
    else:
        initial_username = session.get('mh_chat_username', '') or ''

    return render_template('chat/index.html',
        messages=messages, room=room, initial_chat_username=initial_username)


@chat_bp.route('/api/identity', methods=['POST'])
def api_identity():
    data     = request.get_json(silent=True) or request.form or {}
    username = _clean_username(data.get('username'), fallback='زائر')

    if current_user.is_authenticated:
        username = current_user.get_name() or current_user.username or username
        user_id  = current_user.id
    else:
        user_id = None
        session['mh_chat_username'] = username

    session['mh_chat_room'] = data.get('room', 'general')
    return jsonify({
        'ok':            True,
        'username':      username,
        'user_id':       user_id,
        'authenticated': bool(current_user.is_authenticated),
    })


@chat_bp.route('/api/messages')
def api_messages():
    room     = request.args.get('room', 'general')
    after_id = request.args.get('after_id', type=int, default=0)

    query = ChatMessage.query.filter_by(room=room, is_deleted=False)
    if after_id:
        query = query.filter(ChatMessage.id > after_id)

    messages        = query.order_by(ChatMessage.id.asc()).limit(100).all()
    active_user_id  = current_user.id if current_user.is_authenticated else None

    return jsonify({
        'ok':       True,
        'messages': [_serialize_message(m, active_user_id=active_user_id) for m in messages],
    })


@chat_bp.route('/api/send', methods=['POST'])
def api_send():
    if not current_user.is_authenticated:
        return jsonify({'ok': False, 'error': 'login_required'}), 401

    # ── Per-user send cooldown (flood protection) ──────────────────────────
    now      = datetime.utcnow().timestamp()
    last_key = f'chat_last_send_{current_user.id}'
    last_ts  = session.get(last_key, 0)
    if now - last_ts < _SEND_COOLDOWN_SECS:
        return jsonify({'ok': False, 'error': 'too_fast',
                        'retry_after': _SEND_COOLDOWN_SECS}), 429
    session[last_key] = now

    data     = request.get_json(silent=True) or request.form or {}
    room     = _clean_username(data.get('room', 'general'), fallback='general')[:50]
    message  = _clean_message(data.get('message'))
    msg_type = _clean_username(data.get('type', 'text'), fallback='text')[:20]

    if not message:
        return jsonify({'ok': False, 'error': 'empty_message'}), 400

    chat_msg = ChatMessage(
        user_id      = current_user.id,
        username     = current_user.get_name() or current_user.username or 'زائر',
        message      = message,
        message_type = msg_type,
        room         = room,
    )
    db.session.add(chat_msg)
    db.session.commit()

    return jsonify({
        'ok':      True,
        'message': _serialize_message(chat_msg, active_user_id=current_user.id),
    })


@chat_bp.route('/api/ping')
def api_ping():
    return jsonify({'ok': True, 'time': datetime.utcnow().isoformat()})
