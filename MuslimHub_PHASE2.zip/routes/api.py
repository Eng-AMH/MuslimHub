from flask import Blueprint, jsonify, request
from models import Duaa, Dhikr

api_bp = Blueprint('api', __name__)

# ── CDN key format — must match quran-audio.js CDN_KEY_RE ────────────────────
import re
_CDN_KEY_RE = re.compile(r'^[a-zA-Z][a-zA-Z0-9._-]{1,99}$')

@api_bp.route('/duas')
def get_duas():
    category = request.args.get('category', '')
    q = Duaa.query
    if category:
        q = q.filter_by(category=category)
    duas = q.all()
    return jsonify([{
        'id': d.id,
        'title_ar': d.title_ar,
        'title_en': d.title_en,
        'text_ar': d.text_ar,
        'text_en': d.text_en,
        'category': d.category,
        'source': d.source
    } for d in duas])

@api_bp.route('/adhkar')
def get_adhkar():
    category = request.args.get('category', '')
    q = Dhikr.query
    if category:
        q = q.filter_by(category=category)
    items = q.order_by(Dhikr.order_num).all()
    return jsonify([{
        'id': d.id,
        'title_ar': d.title_ar,
        'text_ar': d.text_ar,
        'text_en': d.text_en,
        'repetitions': d.repetitions,
        'category': d.category,
        'source': d.source
    } for d in items])

@api_bp.route('/reciters')
def get_reciters():
    """Return active reciters as JSON, used by the audio engine and admin tooling."""
    from models import Reciter
    reciters = Reciter.query.filter_by(is_active=True).order_by(Reciter.order_num).all()
    return jsonify([{
        'id':      r.id,
        'name_ar': r.name_ar,
        'name_en': r.name_en or '',
        'cdn_key': r.cdn_key,
        'style':   r.style or 'مرتل',
    } for r in reciters])


@api_bp.route('/audio/validate-key')
def validate_audio_key():
    """
    Lightweight CDN key format check.
    Returns 200 with valid=true/false.  Does NOT make a network request to the CDN;
    that would add latency. Format validation is the correct layer of defence here.
    """
    key = request.args.get('key', '').strip()
    valid = bool(key and _CDN_KEY_RE.match(key))
    return jsonify({'valid': valid, 'key': key})