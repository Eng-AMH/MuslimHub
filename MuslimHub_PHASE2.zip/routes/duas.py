from flask import Blueprint, render_template, request
from models import Duaa
from constants import DUAS_CATEGORIES

duas_bp = Blueprint('duas', __name__)

CATEGORIES = DUAS_CATEGORIES   # backward-compat alias


@duas_bp.route('/')
def index():
    category = request.args.get('category', '')
    search   = request.args.get('q', '')
    page     = request.args.get('page', 1, type=int)

    query = Duaa.query
    if category:
        query = query.filter_by(category=category)
    if search:
        query = query.filter(
            Duaa.text_ar.contains(search) | Duaa.title_ar.contains(search)
        )

    duas = query.order_by(Duaa.order_num).paginate(page=page, per_page=30, error_out=False)

    return render_template(
        'duas/index.html',
        duas=duas, categories=CATEGORIES,
        current_category=category, search=search,
    )
