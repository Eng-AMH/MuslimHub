from flask import Blueprint, render_template
from routes.main import _load_good_deeds   # reuse the same cached loader

good_deeds_bp = Blueprint('good_deeds', __name__)


@good_deeds_bp.route('/')
def index():
    return render_template('good_deeds/index.html', deeds=_load_good_deeds())
