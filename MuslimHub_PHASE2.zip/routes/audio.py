from flask import Blueprint, render_template
from models import Reciter

audio_bp = Blueprint('audio', __name__)

@audio_bp.route('/')
def index():
    reciters = Reciter.query.filter_by(is_active=True).order_by(Reciter.order_num).all()
    return render_template('audio/index.html', reciters=reciters)
