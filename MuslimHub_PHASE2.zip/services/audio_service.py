"""
Server-side audio health checking for reciter CDN sources.

This deliberately mirrors static/js/quran-audio.js's fallback strategy
(CDN_ORIGIN, BITRATES, and the URL template) so an admin "test" click checks
exactly the same URLs a real listener's browser would actually request — not
some parallel logic that could silently drift from what playback really does.

Used by routes/admin.py's reciter health-check endpoint (Master Prompt §2, §29).
"""
import time
import requests

# Keep in sync with static/js/quran-audio.js — CDN_ORIGIN / BITRATES.
CDN_ORIGIN = 'https://cdn.islamic.network/quran/audio-surah'
BITRATES = [128, 64, 192, 48, 40, 32]
REQUEST_TIMEOUT_S = 8


def build_audio_url(surah_num, cdn_key, bitrate=128):
    """Same construction as buildUrl() in quran-audio.js. Returns None if invalid."""
    try:
        n = int(surah_num)
    except (TypeError, ValueError):
        return None
    if n < 1 or n > 114:
        return None
    key = (cdn_key or '').strip()
    if not key:
        return None
    br = int(bitrate) if bitrate in BITRATES else 128
    return f"{CDN_ORIGIN}/{br}/{key}/{n}.mp3"


def _probe(url):
    """
    One HTTP probe of a candidate URL. Uses HEAD first (cheap — no audio bytes
    transferred); some CDN edge nodes don't implement HEAD correctly for range
    requests, so a 405/501 falls back to a tiny ranged GET instead of assuming
    the source is broken.
    Returns (http_status, content_type, latency_ms, error) — error is None on
    a real HTTP response, even a 4xx/5xx one; error is set only for network
    -level failures (timeout, DNS, connection refused, etc).
    """
    start = time.monotonic()
    try:
        resp = requests.head(url, timeout=REQUEST_TIMEOUT_S, allow_redirects=True)
        if resp.status_code in (405, 501):
            resp = requests.get(
                url, timeout=REQUEST_TIMEOUT_S,
                headers={'Range': 'bytes=0-1023'}, stream=True,
            )
            resp.close()
        latency_ms = int((time.monotonic() - start) * 1000)
        return resp.status_code, resp.headers.get('Content-Type'), latency_ms, None
    except requests.exceptions.Timeout:
        return None, None, int((time.monotonic() - start) * 1000), 'timeout'
    except requests.exceptions.RequestException as e:
        return None, None, int((time.monotonic() - start) * 1000), str(e)[:150]


def check_reciter_audio(cdn_key, surah_num=1, bitrates=None):
    """
    Test a reciter's audio source the same way a real listener would
    experience it: try the preferred bitrate, then fall back through the
    same list the client engine uses.

    Returns a dict — never raises:
      status:         'healthy'  (preferred bitrate works)
                       'warning'  (works, but only after falling back — the
                                   admin should know the top-quality source is down)
                       'broken'   (every bitrate failed)
      bitrate:        the bitrate that worked, or None if all failed
      url:            the URL that worked (or the last one tried, if none did)
      http_status, content_type, latency_ms, failure_reason
      attempts:       full per-bitrate detail, for diagnostics
    """
    bitrates = bitrates or BITRATES
    attempts = []

    for i, br in enumerate(bitrates):
        url = build_audio_url(surah_num, cdn_key, br)
        if not url:
            attempts.append({'bitrate': br, 'url': None, 'ok': False, 'error': 'invalid cdn_key/surah'})
            continue

        status, content_type, latency_ms, error = _probe(url)
        ok = error is None and status in (200, 206)
        attempts.append({
            'bitrate': br, 'url': url, 'http_status': status,
            'content_type': content_type, 'latency_ms': latency_ms,
            'ok': ok, 'error': error,
        })

        if ok:
            return {
                'status': 'healthy' if i == 0 else 'warning',
                'bitrate': br, 'url': url, 'http_status': status,
                'content_type': content_type, 'latency_ms': latency_ms,
                'failure_reason': None if i == 0 else f'الجودة المفضّلة (128kbps) غير متاحة — تعمل عبر بديل {br}kbps',
                'attempts': attempts,
            }

    last = attempts[-1] if attempts else {}
    reason = last.get('error') or (f"HTTP {last.get('http_status')}" if last.get('http_status') else 'تعذر الاتصال')
    return {
        'status': 'broken', 'bitrate': None, 'url': last.get('url'),
        'http_status': last.get('http_status'), 'content_type': None,
        'latency_ms': last.get('latency_ms'), 'failure_reason': reason,
        'attempts': attempts,
    }
