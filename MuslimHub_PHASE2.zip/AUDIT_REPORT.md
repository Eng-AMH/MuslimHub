# Muslim Hub — Audit Report
**Date:** August 23, 2026
**Scope:** Full repository audit per Master Prompt §1, plus one critical fix applied and verified during this pass (see §5).

**Method:** This audit was not purely a read-through. The app's real dependencies were installed, the real Flask app was booted, and 39 automated requests were run against it via Flask's test client, including logging in as admin and exercising every admin CRUD screen against the actual shipped `instance/muslimhub.db`. This is called out because it's how the headline bug in §2 was found — static/AST checks (the existing `tools/verify_muslimhub.py`) cannot catch it, because it only manifests when a template actually renders.

---

## 1. Architecture Summary

Muslim Hub is a server-rendered Flask 3 app (Jinja2 templates, vanilla JS, no frontend build step) backed by SQLite via SQLAlchemy, with Flask-Login sessions and a separate cookie-based admin session. It's a genuinely broader product than "Islamic content site" — it has a real social layer (friends, private messages, notifications, a live group chat) alongside the Quran/prayer/adhkar content.

```
app.py            → application factory, blueprint registration, security headers, CSP, rate limiting
app_init.py       → shared extension instances (db, login_manager, csrf)
config.py         → env-driven config, fails loudly if SECRET_KEY is unset
models.py         → 15 SQLAlchemy models (see §6)
constants.py      → shared enums/lookup data
routes/           → 15 blueprints (main, auth, user, quran, audio, prayer, adhkar,
                     duas, hadith, tasbeeh, memorial, chat, good_deeds, api, admin)
templates/        → Jinja2, organized by feature area; templates/admin/ for the CMS
static/js/        → vanilla JS modules (quran-audio.js is the standout — see §4)
static/sw.js      → service worker (versioned caching, see §4)
static/manifest.json → PWA manifest
data/*.json       → seed content for duas/adhkar/hadith (Quran text itself is NOT
                     stored locally — it's fetched live from alquran.cloud, and
                     prayer times from aladhan.com — correctly keeping the app out
                     of the business of ever generating/storing canonical text)
instance/muslimhub.db → the live SQLite database (11 users, 41 duas, 75 adhkar,
                     15 hadith, 33 reciters, 13 chat messages already present)
```

No Docker, no Node build, no migration framework (Alembic/Flask-Migrate) — schema
changes currently rely on `db.create_all()` plus hand-written repair logic in the
app factory (e.g. the reciter-key migration on startup). This works for *additive*
changes but has no story for renaming/dropping a column. Flag for §9.

**What's already good here, concretely:**
- No raw/string-formatted SQL anywhere — everything goes through the SQLAlchemy ORM. No SQL-injection surface found.
- No `eval`, `exec`, `os.system`, `subprocess`, `pickle`, or unsafe `yaml.load` anywhere in the codebase.
- CSP, security headers, rate limiting (Flask-Limiter), open-redirect protection on `next=` params, and password-strength validation are all already implemented in `app.py`/`routes/auth.py` and are reasonable.
- `SESSION_COOKIE_SAMESITE=Lax` + `HttpOnly` + `Secure` (in production) are set correctly in `config.py`.

---

## 2. Critical Bug Found and Fixed: Admin Panel Was Broken

**This was the single most important finding.** `CSRFProtect` (Flask-WTF) was never
initialized anywhere in the app, despite the code clearly intending it to be —
`WTF_CSRF_ENABLED = True` is set in config, `routes/admin.py` manually calls
`validate_csrf()`, and 12 admin templates call `{{ csrf_token() }}`.

Without `CSRFProtect(app)`, the Jinja global `csrf_token()` simply doesn't exist.
I verified this empirically (not just by reading the code):

```
UndefinedError: 'csrf_token' is undefined
```

**Effect:** any admin page that renders at least one row of content containing an
action form crashes with an HTTP 500. Tested directly against your real database:

| Route | Before fix | Rows in real DB |
|---|---|---|
| `/admin/duas` | **500** | 41 |
| `/admin/adhkar` | **500** | 75 |
| `/admin/hadiths` | **500** | 15 |
| `/admin/reciters` | **500** | 33 |
| `/admin/users` | **500** | 11 |
| `/admin/featured` | **500** | (form always renders) |
| `/admin/memorials`, `/admin/chat-messages`, `/admin/reports` | 200 (luck) | 0 memorials, 0 reports at test time — **these would break the moment one row exists** |

In short: on your actual production database, the admin CMS was almost entirely
unusable. This also means the "test reciter/admin audio health check" tooling the
master prompt asks for (§2, §29) would have been built on top of a panel that
doesn't load — worth knowing before Phase 8.

**Second-order finding, same root cause:** because `CSRFProtect` was never active,
*no* form or `fetch()` call anywhere in the app — admin or not — was actually
protected against cross-site request forgery. I confirmed this is exploitable, not
just theoretical, by sending a forged `POST /user/edit` with **zero** CSRF token
from a fresh session: it succeeded and applied the change. To be precise about real-world
risk: `SESSION_COOKIE_SAMESITE=Lax` (already set correctly) blocks the classic
auto-submitting cross-site `<form>` attack in modern browsers, so this wasn't a
trivial one-click exploit — but relying solely on `SameSite` instead of an explicit
token is a real gap versus OWASP-recommended defense-in-depth, and it's not what
the code's own config/intent suggests was meant to ship.

### What I fixed (implemented and verified, not just diagnosed)

1. Added a shared `CSRFProtect` instance in `app_init.py`, initialized in `app.py` alongside `db`/`login_manager`.
2. Added a friendly `CSRFError` handler (flash message + redirect back) instead of surfacing Flask-WTF's raw 400 page to a normal visitor whose tab just sat open too long.
3. Added the `{{ csrf_token() }}` hidden field to every server-rendered `<form method="post">` that was missing it: `auth/login.html`, `auth/signup.html`, `auth/change_password.html`, `admin/login.html`, `memorial/index.html` (×2), `user/conversation.html`, `user/edit_profile.html`, `user/friends.html` (×3), `user/profile.html` (×3).
4. Added a global `<meta name="csrf-token">` tag + `CSRF_TOKEN` JS constant in `base.html`, and wired the `X-CSRFToken` header into every JS `fetch()` POST call: salawat-dismiss, both chat send paths, and both friend-request call sites (`user/profile.html`, `user/search.html`).
5. Wrote a real regression-test suite (`tests/test_csrf_protection.py`, `tests/test_smoke.py` — 39 tests, all passing) so this class of bug can't silently reappear. See §10.

**Verified, not assumed:** all 9 previously-crashing admin pages now return 200
against real data; 31 public routes show zero regressions; a forged POST with no
token is now correctly rejected; a real signup → edit-profile flow with a valid
token still works end-to-end; an admin content-add (`/admin/duas/add`) still works
correctly with the pre-existing manual `validate_csrf()` layered underneath the
new global check (no double-rejection).

---

## 3. Second Critical Item: Leaked Production Credentials

`DEPLOY.md` contains the live admin username and password in plaintext, in a file
that's part of what you'd hand to a deployment target or keep in version control.
**This needs to be rotated immediately, independent of anything else in this
report**, and removed from any file that gets committed or shared. Longer-term:
generate `ADMIN_PASSWORD` at deploy time and never write real credentials into a
markdown file — `.env.example` already models the right pattern (placeholder
values only); `DEPLOY.md` should point to it rather than containing real secrets.

---

## 4. What's Already Genuinely Solid

Two subsystems clearly already got serious engineering attention, and match a
surprising amount of the master prompt's spec already:

**`static/js/quran-audio.js` (497 lines).** A real state machine (idle → loading →
buffering → playing/paused → recovering/failed), adaptive bitrate fallback across
multiple qualities before giving up on a reciter, exponential backoff retry,
`play()` rejection handling for autoplay restrictions, and clean pub/sub events for
the UI to subscribe to. This is most of what master-prompt §2 asks for. Gaps
worth closing in Phase 2 rather than rebuilt from scratch: no explicit
`offline`/`blocked-by-browser` states (currently folded into generic error
handling), no `navigator.onLine` integration, and no admin-facing health-check
endpoint (§29 is genuinely unbuilt — see §7).

**Qibla compass, embedded in `templates/prayer/index.html`.** Correct circular-angle
smoothing (handles the 359°→0° wraparound properly, not naive averaging), iOS
`webkitCompassHeading` + Android `deviceorientationabsolute`/`alpha` handling,
proper `requestPermission()` flow for iOS 13+, de-duplicated event listener
registration, and it already refuses to show a fake `0°` before a real reading
exists — all specifically called out in master-prompt §5. It even already shows
"أنت تواجه القبلة" ("You are facing the Qibla") as a subtle badge, matching the
spec's exact example. Real gap: if geolocation is denied, Qibla has no fallback to
the manual city already selected elsewhere on the same page for prayer times —
each feature's location handling is siloed. Small, worth fixing in Phase 4.

Given this, **Phases 2 and 4 of the master prompt's own roadmap are largely
"close remaining gaps," not "build from zero."**

---

## 5. Feature Map: Master Prompt vs. Reality

| Area | Status | Notes |
|---|---|---|
| Quran text/reading, audio Quran | ✅ Built, solid | External API for text (correct — never LLM-generated); audio engine is strong (§4) |
| Prayer times | ✅ Built | Aladhan API, geolocation + manual city, calculation method param |
| Qibla/compass | ✅ Built, solid | See §4 |
| Adhkar, Duas, Hadith, Tasbeeh | ✅ Built | Seeded from `data/*.json`, source metadata present |
| Memorial (remembrance posts) | ✅ Built | |
| Social (friends, DMs, notifications) | ✅ Built | Broader than the master prompt describes |
| Group chat | ✅ Built | Polling-based, not SocketIO — `DEPLOY.md` is stale here (still describes SocketIO) |
| Good deeds | ✅ Built | Static content list, not a per-user tracked model |
| Admin CMS (content) | ⚠️ Was broken, now fixed | See §2 |
| PWA / offline shell | ⚠️ Partial | Manifest + SW exist; offline **audio** caching is wired in the service worker but has **no UI trigger anywhere** — dead code path (see §9) |
| Favorites | ⚠️ Client-side only | `/favorites` route exists but there's no `Favorite` model — nothing syncs across devices or survives a logout. Master-prompt §38 (“unify favorites”) requires a real model |
| Password recovery | ❌ Missing | Only "change password while logged in" exists; no forgot-password/email-reset flow. `EMAIL_HOST_USER`/`EMAIL_HOST_PASSWORD` are defined in config but referenced nowhere else in the codebase — vestigial |
| Adhan engine (§3) | ❌ Not built | No Adhan audio, scheduling, or settings exist yet |
| Living Wallpaper (§6–9, §18–20, §58–60) | ❌ Not built | Zero wallpaper code, models, or admin tooling exist |
| Desktop Companion (§6, §56–57) | ❌ Not built | This is a separate application (the master prompt is right that a website can't change an OS wallpaper) |
| Islamic events engine (§18) | ❌ Not built | |
| Unified notification/reminder scheduler (§16) | ❌ Not built | Only the salawat-dismiss banner exists; no central scheduler |
| Saved Moments (§20), Daily Intent (§21), Deen/Focus Mode (§12) | ❌ Not built | |
| Admin: wallpapers/Adhan/content-health/audio-health (§26–29) | ❌ Not built | |
| Automated tests | ⚠️ Was static-only | `tools/verify_muslimhub.py` does AST/import checks only, never renders a template or hits a route — this is exactly why §2's bug went undetected. Real `pytest` suite added this pass (§10) |

---

## 6. Data Model (as it exists today)

`User, Friendship, PrivateMessage, Notification, Report, Duaa, Dhikr, Hadith,
Memorial, ChatMessage, Reciter, Admin, AuditLog, FeaturedContent, SiteSettings` —
15 models, no `Favorite`, `Wallpaper`, `AdhanSound`, `IslamicEvent`,
`UserReminder`, `SavedMoment`, `DailyIntent`, or `AudioHealthCheck` model exists
yet. All of §37's proposed models are genuinely new additions, not renames of
something existing.

**Migration safety note:** there is no Alembic/Flask-Migrate in `requirements.txt`.
Adding new tables (Wallpaper, AdhanSound, etc.) is low-risk with the current
`db.create_all()`-on-startup approach. Anything that alters an *existing* table
(e.g. adding a column to `User`) is not — `create_all()` silently does nothing for
existing tables, so a manual migration function (matching the pattern already used
for the reciter-key repair) or introducing Flask-Migrate should happen before
Phase 6, not during it.

---

## 7. Recommended Architecture for New Work

The master prompt's own proposed layout (§35) is right and matches how this
codebase already thinks (blueprints, not one giant file):

```
services/
  audio_service.py       # health-check logic backing an admin endpoint (§29)
  prayer_service.py       # already partly exists as inline logic in routes/prayer.py — extract
  qibla_service.py
  reminder_service.py     # the central scheduler §16 asks for — nothing like this exists yet
  event_service.py
  wallpaper_service.py
  notification_service.py
  content_service.py

desktop_companion/        # a SEPARATE application — see §8 below
static/js/                # keep the existing pattern; quran-audio.js is the model to follow
```

New DB models only where §6 identifies a real gap — `Favorite` (unifying the
currently client-side-only favorites), `Wallpaper`/`WallpaperPack`, `AdhanSound`,
`IslamicEvent`, `UserReminder`, `SavedMoment`, `DailyIntent`, `AudioHealthCheck`.

---

## 8. On the Desktop Companion, Specifically

The master prompt is correct that a browser tab cannot reliably change an OS
desktop wallpaper — that genuinely requires a separate native/Tauri application.
I want to be direct about scope here rather than quietly under-deliver on it: a
real, shippable desktop companion (scheduler, wallpaper engine, tray UI,
notifications, offline cache, an installer, and Windows/macOS/Linux support) is a
multi-week project in its own right, separate from the Flask codebase. It's real
work I can do, but not inside the same pass as fixing the web app — it deserves
its own phase with its own testing loop rather than being rushed alongside
everything else. See the roadmap in §9.

---

## 9. Other Findings Worth Knowing About (non-blocking)

- **Admin login has no dedicated rate limit.** `routes/auth.py`'s blueprint gets `limiter.limit("10 per minute")`; `admin_bp` does not, so brute-forcing `/admin/login` is only bounded by the app-wide default (200/day, 50/hour) — much looser than intended for a login endpoint guarding the whole CMS.
- **Offline audio download is scaffolded but unreachable.** `static/sw.js` implements `CACHE_AUDIO_SURAH`, but no template ever calls it — `templates/settings.html` only wires up text caching and explicitly labels it "text only, no audio." Worth finishing before advertising it in §23's "Manage Offline Storage" UI, and note it also hardcodes a 128kbps URL rather than sharing the audio engine's adaptive-bitrate logic, so it would silently fail for reciters that need a fallback bitrate.
- **`/chat/api/identity` is dead code** — defined in `routes/chat.py`, never called from any template.
- **`GROQ_API_KEY`** is defined in config and mentioned in `.env.example` but used nowhere — either finish or remove the reference so it doesn't look like an AI-chat feature exists.
- **`datetime.utcnow()`** is used throughout (`app.py`, `routes/admin.py`, Flask-Login internals) and is deprecated as of Python 3.12 in favor of timezone-aware `datetime.now(datetime.UTC)`. Not urgent, but a good low-risk cleanup to bundle into Phase 1 hardening.
- **`Flask-Limiter` uses `storage_uri="memory://"`**, which is fine for a single-process deployment but resets on every restart and won't work correctly if the app ever runs multiple worker processes — worth a Redis-backed store before scaling beyond one process.
- **Repo hygiene:** an empty `templates/{auth,user,hadith}` directory (literal curly-brace folder name, likely a leftover from a shell brace-expansion typo) and a stale `DEPLOY.md` (still documents a SocketIO-based chat architecture that was replaced with polling) — both harmless but worth cleaning up.

---

## 10. Testing Added This Pass

`tests/` (pytest, 39 tests, all passing against a real app instance + throwaway
SQLite DB per test — never touches `instance/muslimhub.db`):
- `test_smoke.py` — every public route/API endpoint loads without a 5xx, clean 404s where expected.
- `test_csrf_protection.py` — regression-locks the §2 fix specifically: previously-crashing admin pages now load; a tokenless forged POST is rejected; a real signup→edit flow with a valid token still works end-to-end; admin content-add still works with the old manual check layered under the new global one.

Run with: `pytest tests/ -v` (needs `pytest`, not yet in `requirements.txt` — add as a dev dependency).

This is a first slice of master-prompt §46, not full coverage — no tests yet for the compass angle-wrap math, the audio fallback state machine, or scheduling logic, since those are Phase 2/4 work.

---

## 11. Proposed Implementation Order

The master prompt's own §64 ordering is sound and I'd keep it, with Phase 1 now
concretely done rather than theoretical:

| Phase | Content | Status |
|---|---|---|
| 1 | Audit + regression baseline | **Done this pass** — audit above, CSRF bug fixed & tested, 39-test baseline in place |
| 2 | Quran audio: close the gaps in §4 (explicit offline/blocked states, admin health-check endpoint, finish the orphaned offline-download UI) | Not started — engine is already ~80% there |
| 3 | Prayer engine hardening + Adhan engine (net new) + notification scheduler (net new) | Not started |
| 4 | Qibla: manual-city fallback when GPS denied, confidence/quality indicator | Not started — mostly polish on an already-solid base |
| 5 | Unified reminder/scheduler service | Not started |
| 6 | Wallpaper/content engine + new DB models | Not started — needs a migration story first (§6) |
| 7 | Desktop Companion (separate app) | Not started — see §8 on scope |
| 8 | Admin CMS: wallpapers, Adhan, content-health, audio-health | Not started — now buildable, since the admin panel itself works again |
| 9 | Offline/PWA improvements | Partial — finish what's already scaffolded (§9) |
| 10 | UX polish, performance, accessibility | Not started |
| 11 | Testing, security, deployment docs | Started (§10) — rotate the leaked credential (§3) as part of this |

## 12. Risks If Work Continues Without Reading This

- Building Phase 6+ admin tooling before the migration story (§6) exists means every new model risks becoming another `db.create_all()`-only table with no safe path to ever change its schema later.
- Advertising offline audio (§23) before finishing the orphaned caching path (§9) will produce silent failures for some reciters.
- Shipping with the leaked credential (§3) live is the highest-severity outstanding item in this entire report — higher than any feature gap.
