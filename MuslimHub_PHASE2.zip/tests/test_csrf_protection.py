"""
Regression tests for the CSRF bug found during the Aug 2026 audit:

    CSRFProtect was never initialized on the app, which meant:
      1) {{ csrf_token() }} — used by 12 admin templates — was an undefined
         Jinja global, so any admin list/form page crashed with a 500 as
         soon as it had a row of real content to render.
      2) No form or fetch() call anywhere in the app (admin or not) was
         actually protected against cross-site request forgery.

    Fixed by initializing CSRFProtect in app_init.py/app.py, adding the
    hidden csrf_token field to every server-rendered POST form, and adding
    the X-CSRFToken header to every JS fetch() POST call.

These tests exist so this can't silently regress.
"""
from tests.conftest import get_csrf_token, signup, admin_login

# Admin pages that were empirically confirmed to 500 before the fix, because
# their list view renders at least one row containing a delete/action form.
PREVIOUSLY_CRASHING_ADMIN_PAGES = [
    "/admin/duas", "/admin/duas/add",
    "/admin/adhkar", "/admin/adhkar/add",
    "/admin/hadiths", "/admin/hadiths/add",
    "/admin/featured", "/admin/users", "/admin/reciters",
]


def test_admin_pages_no_longer_crash(client):
    admin_login(client)
    for path in PREVIOUSLY_CRASHING_ADMIN_PAGES:
        resp = client.get(path)
        assert resp.status_code == 200, f"{path} still broken (status {resp.status_code})"


def test_post_without_csrf_token_is_rejected(client):
    """A forged cross-site POST with zero CSRF token must never take effect."""
    resp = client.post("/user/edit", data={"display_name": "FORGED-NO-TOKEN"})
    assert b"FORGED-NO-TOKEN" not in resp.data


def test_signup_requires_a_valid_csrf_token(client):
    resp = client.post(
        "/auth/signup",
        data={
            "username": "notoken", "display_name": "No Token",
            "email": "notoken@example.com", "password": "TestPass123",
            "confirm": "TestPass123", "avatar": "🧕",
            # no csrf_token field at all
        },
    )
    # Should be redirected/rejected, not create the account
    from models import User
    from app import create_app  # noqa: reuse app context already pushed by fixture
    with client.application.app_context():
        assert User.query.filter_by(username="notoken").first() is None


def test_real_signup_and_profile_edit_flow_still_works(client):
    """The whole point of CSRF protection is that legitimate requests still work."""
    signup(client, username="realflowuser")
    tok = get_csrf_token(client, "/user/edit")
    resp = client.post(
        "/user/edit",
        data={"display_name": "Real Flow Updated", "bio": "hi", "privacy": "public", "csrf_token": tok},
        follow_redirects=True,
    )
    assert resp.status_code == 200
    assert b"Real Flow Updated" in resp.data


def test_admin_can_still_add_content_with_valid_token(client):
    """The pre-existing manual _validate_admin_csrf() in admin.py must coexist
    peacefully with the new global CSRFProtect hook, not double-reject valid requests."""
    admin_login(client)
    tok = get_csrf_token(client, "/admin/duas/add")
    resp = client.post(
        "/admin/duas/add",
        data={
            "category": "test", "arabic_text": "اختبار",
            "translation": "test dua", "source": "audit",
            "csrf_token": tok,
        },
        follow_redirects=True,
    )
    assert resp.status_code == 200

    from models import Duaa
    with client.application.app_context():
        assert Duaa.query.filter_by(category="test").count() == 1
