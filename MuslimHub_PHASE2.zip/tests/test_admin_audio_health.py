"""
Tests for the admin-triggered reciter health-check route
(POST /admin/reciters/test/<id>). The HTTP probe itself is mocked — this file
tests the route's auth/CSRF/storage behavior, not CDN reachability.
"""
from unittest.mock import patch
from tests.conftest import get_csrf_token, admin_login


HEALTHY_RESULT = {
    'status': 'healthy', 'bitrate': 128,
    'url': 'https://cdn.islamic.network/quran/audio-surah/128/ar.alafasy/1.mp3',
    'http_status': 200, 'content_type': 'audio/mpeg', 'latency_ms': 120,
    'failure_reason': None, 'attempts': [],
}

BROKEN_RESULT = {
    'status': 'broken', 'bitrate': None, 'url': None,
    'http_status': 404, 'content_type': None, 'latency_ms': 80,
    'failure_reason': 'HTTP 404', 'attempts': [],
}


def _seed_reciter(app):
    from app_init import db
    from models import Reciter
    with app.app_context():
        r = Reciter(name_ar='قارئ اختبار', cdn_key='ar.alafasy', is_active=True, order_num=0)
        db.session.add(r)
        db.session.commit()
        return r.id


def test_requires_admin_login(client, app):
    rid = _seed_reciter(app)
    # no admin session at all
    resp = client.post(f'/admin/reciters/test/{rid}', data={}, follow_redirects=True)
    # should land on the admin login page, not perform the check
    assert b'admin' in resp.request.path.encode() or resp.status_code == 200
    with app.app_context():
        from models import AudioHealthCheck
        assert AudioHealthCheck.query.count() == 0


def test_requires_csrf_token(client, app):
    rid = _seed_reciter(app)
    admin_login(client)
    with patch('services.audio_service.check_reciter_audio', return_value=HEALTHY_RESULT):
        client.post(f'/admin/reciters/test/{rid}', data={})  # no csrf_token field
    with app.app_context():
        from models import AudioHealthCheck
        assert AudioHealthCheck.query.count() == 0


def test_stores_healthy_result(client, app):
    rid = _seed_reciter(app)
    admin_login(client)
    tok = get_csrf_token(client, '/admin/reciters')
    with patch('services.audio_service.check_reciter_audio', return_value=HEALTHY_RESULT):
        resp = client.post(f'/admin/reciters/test/{rid}', data={'csrf_token': tok}, follow_redirects=True)
    assert resp.status_code == 200
    with app.app_context():
        from models import AudioHealthCheck
        check = AudioHealthCheck.query.filter_by(reciter_id=rid).first()
        assert check is not None
        assert check.status == 'healthy'
        assert check.bitrate == 128
        assert check.checked_by == 'test_admin'


def test_stores_broken_result_and_never_hides_it(client, app):
    """Master Prompt §29: 'Never silently expose a broken reciter as healthy.'"""
    rid = _seed_reciter(app)
    admin_login(client)
    tok = get_csrf_token(client, '/admin/reciters')
    with patch('services.audio_service.check_reciter_audio', return_value=BROKEN_RESULT):
        resp = client.post(f'/admin/reciters/test/{rid}', data={'csrf_token': tok}, follow_redirects=True)
    assert resp.status_code == 200
    with app.app_context():
        from models import AudioHealthCheck
        check = AudioHealthCheck.query.filter_by(reciter_id=rid).first()
        assert check.status == 'broken'

    # and the broken status must be visible on the reciters page itself
    page = client.get('/admin/reciters')
    assert 'معطّل'.encode() in page.data


def test_health_history_is_kept_not_overwritten(client, app):
    """Multiple tests over time should accumulate, not just track 'last status',
    so an admin can see whether a source is flaky."""
    rid = _seed_reciter(app)
    admin_login(client)
    for result in (HEALTHY_RESULT, BROKEN_RESULT, HEALTHY_RESULT):
        tok = get_csrf_token(client, '/admin/reciters')
        with patch('services.audio_service.check_reciter_audio', return_value=result):
            client.post(f'/admin/reciters/test/{rid}', data={'csrf_token': tok}, follow_redirects=True)
    with app.app_context():
        from models import AudioHealthCheck
        assert AudioHealthCheck.query.filter_by(reciter_id=rid).count() == 3
