"""
Baseline smoke tests: every public page and API endpoint should load without
a server error. This is a regression net, not a correctness check — it exists
to catch "the page 500s" bugs, which static syntax checks (tools/verify_muslimhub.py)
cannot catch because they never actually render a template.

This is exactly the class of bug that shipped previously: the admin panel's
csrf_token() crash was invisible to import/syntax checks and only showed up
once a template was actually rendered against real data. See test_csrf_protection.py.
"""
import pytest

PUBLIC_GET_ROUTES = [
    "/", "/quran/", "/quran/1", "/audio/", "/adhkar/", "/adhkar/morning",
    "/adhkar/evening", "/adhkar/protection", "/duas/", "/hadith/", "/tasbeeh/",
    "/prayer/", "/memorial/", "/chat/", "/good-deeds/", "/favorites",
    "/settings", "/about", "/contact", "/privacy", "/terms",
    "/auth/login", "/auth/signup", "/admin/login",
    "/api/duas", "/api/adhkar", "/api/reciters",
    "/robots.txt", "/sitemap.xml", "/static/manifest.json", "/static/sw.js",
]


@pytest.mark.parametrize("path", PUBLIC_GET_ROUTES)
def test_public_route_does_not_error(client, path):
    resp = client.get(path)
    assert resp.status_code < 500, f"{path} returned {resp.status_code}"


def test_unknown_route_is_a_clean_404(client):
    resp = client.get("/this-route-does-not-exist")
    assert resp.status_code == 404


def test_invalid_surah_number_is_not_a_server_error(client):
    # surah 999 doesn't exist; the route should handle it gracefully, not 500
    resp = client.get("/quran/999")
    assert resp.status_code < 500


def test_non_integer_surah_is_404(client):
    resp = client.get("/quran/abc")
    assert resp.status_code == 404
