"""
Unit tests for services/audio_service.py.

All HTTP calls are mocked — these tests must never touch the real CDN. That's
intentional: this sandbox's network is restricted to package registries, so
live-CDN reachability cannot be verified here at all (see AUDIT_REPORT.md).
These tests instead lock down the *logic*: URL construction, the bitrate
fallback order, and how different failure modes get classified.
"""
from unittest.mock import patch, MagicMock
import requests

from services.audio_service import build_audio_url, check_reciter_audio, BITRATES


def test_build_audio_url_valid():
    url = build_audio_url(1, 'ar.alafasy', 128)
    assert url == 'https://cdn.islamic.network/quran/audio-surah/128/ar.alafasy/1.mp3'


def test_build_audio_url_invalid_surah_number():
    assert build_audio_url(0, 'ar.alafasy') is None
    assert build_audio_url(115, 'ar.alafasy') is None
    assert build_audio_url('not-a-number', 'ar.alafasy') is None


def test_build_audio_url_empty_key():
    assert build_audio_url(1, '') is None
    assert build_audio_url(1, None) is None


def test_build_audio_url_unknown_bitrate_falls_back_to_128():
    # mirrors buildUrl() in quran-audio.js: an out-of-list bitrate defaults to 128
    url = build_audio_url(1, 'ar.alafasy', 999)
    assert '/128/' in url


def _resp(status=200, headers=None):
    m = MagicMock()
    m.status_code = status
    m.headers = headers or {'Content-Type': 'audio/mpeg'}
    return m


def test_healthy_when_first_bitrate_works():
    with patch('services.audio_service.requests.head', return_value=_resp(200)) as mock_head:
        result = check_reciter_audio('ar.alafasy', surah_num=1)
    assert result['status'] == 'healthy'
    assert result['bitrate'] == BITRATES[0]
    assert result['failure_reason'] is None
    mock_head.assert_called_once()  # only tried the first bitrate — no need to fall back


def test_warning_when_only_a_fallback_bitrate_works():
    responses = [_resp(404), _resp(200)]  # 128kbps 404s, 64kbps (next in BITRATES) works
    with patch('services.audio_service.requests.head', side_effect=responses):
        result = check_reciter_audio('ar.somereciter', surah_num=1)
    assert result['status'] == 'warning'
    assert result['bitrate'] == BITRATES[1]
    assert 'kbps' in result['failure_reason']


def test_broken_when_every_bitrate_fails():
    with patch('services.audio_service.requests.head', return_value=_resp(404)):
        result = check_reciter_audio('ar.doesnotexist', surah_num=1)
    assert result['status'] == 'broken'
    assert result['bitrate'] is None
    assert len(result['attempts']) == len(BITRATES)  # tried every fallback, gave up honestly


def test_broken_on_network_timeout():
    with patch('services.audio_service.requests.head', side_effect=requests.exceptions.Timeout):
        result = check_reciter_audio('ar.alafasy', surah_num=1)
    assert result['status'] == 'broken'
    assert result['failure_reason'] == 'timeout'


def test_head_405_falls_back_to_ranged_get():
    """Some CDN edge nodes reject HEAD; we must not report those as broken
    without trying a small ranged GET first."""
    with patch('services.audio_service.requests.head', return_value=_resp(405)), \
         patch('services.audio_service.requests.get', return_value=_resp(206)) as mock_get:
        result = check_reciter_audio('ar.alafasy', surah_num=1)
    assert result['status'] == 'healthy'
    assert mock_get.called
    # must request a small range, not the whole file
    assert 'Range' in mock_get.call_args.kwargs.get('headers', {})


def test_never_raises_on_unexpected_exception_type():
    """The service must degrade to 'broken', never crash the admin route."""
    with patch('services.audio_service.requests.head', side_effect=requests.exceptions.ConnectionError('dns fail')):
        result = check_reciter_audio('ar.alafasy', surah_num=1)
    assert result['status'] == 'broken'
    assert 'dns fail' in result['failure_reason']
