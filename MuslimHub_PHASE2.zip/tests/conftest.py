"""
Shared pytest fixtures for the Muslim Hub test suite.

Each test gets its own throwaway SQLite database and its own Flask test
client, so tests never touch instance/muslimhub.db (the real content) and
never interfere with each other.
"""
import os
import re
import tempfile
import pytest

os.environ.setdefault("SECRET_KEY", "pytest-only-secret-key-not-for-deployment")
os.environ.setdefault("ADMIN_USERNAME", "test_admin")
os.environ.setdefault("ADMIN_PASSWORD", "TestAdminPass!2026")


@pytest.fixture()
def app():
    db_fd, db_path = tempfile.mkstemp(suffix=".db")
    os.environ["DATABASE_URL"] = "sqlite:///" + db_path

    from app import create_app
    flask_app = create_app()
    flask_app.config.update(TESTING=True)

    yield flask_app

    os.close(db_fd)
    os.unlink(db_path)


@pytest.fixture()
def client(app):
    return app.test_client()


def get_csrf_token(client, path):
    """Fetch a page and pull the CSRF token out of it (form field or meta tag)."""
    resp = client.get(path)
    html = resp.data.decode("utf-8", "ignore")
    m = re.search(r'name="csrf_token" value="([^"]+)"', html)
    if not m:
        m = re.search(r'name="csrf-token" content="([^"]+)"', html)
    assert m, f"No CSRF token found on {path} (status {resp.status_code})"
    return m.group(1)


def signup(client, username="pytestuser", email=None):
    """Sign up a fresh user through the real form flow and return the username."""
    email = email or f"{username}@example.com"
    tok = get_csrf_token(client, "/auth/signup")
    resp = client.post(
        "/auth/signup",
        data={
            "username": username,
            "display_name": "Pytest User",
            "email": email,
            "password": "TestPass123",
            "confirm": "TestPass123",
            "avatar": "🧕",
            "csrf_token": tok,
        },
        follow_redirects=True,
    )
    assert resp.status_code == 200
    return username


def admin_login(client):
    tok = get_csrf_token(client, "/admin/login")
    resp = client.post(
        "/admin/login",
        data={
            "username": os.environ["ADMIN_USERNAME"],
            "password": os.environ["ADMIN_PASSWORD"],
            "csrf_token": tok,
        },
        follow_redirects=True,
    )
    assert resp.status_code == 200
