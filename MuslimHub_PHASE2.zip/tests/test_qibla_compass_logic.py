"""
Executes the *actual* Qibla/compass JS (extracted from the real rendered
/prayer/ page, not a hand-copied duplicate that could drift from the source)
under Node, and checks real outputs — angle wrap-around, the great-circle
Qibla bearing formula, and the heading-quality state logic added this pass.

This is the class of test master-prompt §46 explicitly asks for ("angle
wrap-around", "compass smoothing") and that pure syntax-checking
(test_frontend_js.py) or Python-only tests can't cover, since the logic
lives entirely in template-embedded JS.

Approach: the script has no module system, so we can't `require()` a piece
of it. Instead we extract everything from the start of the <script> block up
to the `/* Init */` marker (verified to contain zero top-level side effects —
only `let`/`function`/`const` declarations), which means it can run under
Node with no DOM/canvas/fetch stubbing at all. A few bridge lines expose the
functions/state we want to poke at from outside.
"""
import json
import re
import shutil
import subprocess
import tempfile
import os
import pytest

NODE_AVAILABLE = shutil.which('node') is not None


def _extract_compass_snippet(client):
    resp = client.get('/prayer/')
    assert resp.status_code == 200
    html = resp.data.decode('utf-8')

    scripts = re.findall(r'<script>(.*?)</script>', html, re.DOTALL)
    full_script = next((s for s in scripts if 'function calcQibla' in s), None)
    assert full_script, "couldn't find the script block containing calcQibla on /prayer/"

    assert '/* Init */' in full_script, (
        "the /* Init */ marker this test relies on to strip side-effecting "
        "code is missing — did templates/prayer/index.html change?"
    )
    declarations_only = full_script.split('/* Init */')[0]

    assert 'function calcQibla' in declarations_only
    assert 'function normalizeHeading' in declarations_only
    assert 'function getHeadingQuality' in declarations_only
    assert 'function useResolvedCoordsForQibla' in declarations_only
    return declarations_only


BRIDGE = """
global.__normalizeHeading = normalizeHeading;
global.__calcQibla = calcQibla;
global.__getHeadingQuality = getHeadingQuality;
global.__setHeadingState = function (hh, src, agoMs) {
  hasHeading = hh;
  headingSource = src;
  lastGoodReadingAt = Date.now() - agoMs;
};
global.__useResolvedCoordsForQibla = useResolvedCoordsForQibla;
global.__setLastResolvedCoords = (v) => { lastResolvedCoords = v; };
global.__getQiblaAngle = () => qiblaAngle;
"""


DOM_STUB = """
function __dummyEl() {
  return {
    style: {}, classList: { add(){}, remove(){}, toggle(){}, contains(){ return false; } },
    textContent: '', value: '', innerHTML: '',
    addEventListener(){}, removeEventListener(){}, setAttribute(){}, getAttribute(){ return null; },
    appendChild(){}, querySelector(){ return __dummyEl(); }, focus(){}, click(){},
    getContext(){ return { clearRect(){}, beginPath(){}, arc(){}, stroke(){}, fill(){}, moveTo(){}, lineTo(){}, closePath(){}, save(){}, restore(){}, translate(){}, rotate(){}, fillText(){}, measureText(){ return {width:0}; } }; },
  };
}
const document = {
  getElementById: () => __dummyEl(),
  querySelector: () => __dummyEl(),
  querySelectorAll: () => [],
  addEventListener: () => {},
  createElement: () => __dummyEl(),
};
const window = { screen: {}, addEventListener(){}, removeEventListener(){}, isSecureContext: true };
const navigator = { geolocation: null };
global.requestAnimationFrame = () => 1;  // no-op: don't actually recurse in a sync test
global.cancelAnimationFrame = () => {};
"""


def _run_node_checks(snippet, checks_js):
    """checks_js: JS source that runs assertions (Node's assert module is
    preloaded) and, on success, writes {"ok": true} as the last line of
    stdout. Any thrown assertion produces a non-zero exit + node's own
    error text on stderr, which we surface directly in the pytest failure.

    A generic DOM stub is provided so incidental top-level element access in
    the extracted snippet (e.g. setting an initial date display) degrades to
    a harmless no-op instead of crashing the whole check — trying to
    text-detect and strip every such statement is fragile (this test caught
    a real multi-line one during development that a text scan missed)."""
    combined = (
        "const assert = require('assert');\n"
        + DOM_STUB + "\n"
        + snippet + "\n" + BRIDGE + "\n" + checks_js
        + "\nconsole.log(JSON.stringify({ok: true}));\n"
    )
    with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
        f.write(combined)
        path = f.name
    try:
        result = subprocess.run(['node', path], capture_output=True, text=True, timeout=10)
        if result.returncode != 0:
            pytest.fail(f"Node assertion failed:\n{result.stderr}")
        assert json.loads(result.stdout.strip().splitlines()[-1]) == {"ok": True}
    finally:
        os.unlink(path)


# ── Reference bearings, computed independently in Python with the same
# standard great-circle initial-bearing formula, as an oracle for the JS. ──
QIBLA_REFERENCE = {
    "Cairo":    (30.0444, 31.2357, 136.14),
    "London":   (51.5074, -0.1278, 118.99),
    "Jakarta":  (-6.2088, 106.8456, 295.15),
    "New York": (40.7128, -74.0060, 58.48),
}


@pytest.mark.skipif(not NODE_AVAILABLE, reason="node not available in this environment")
def test_calc_qibla_matches_independent_reference(client):
    snippet = _extract_compass_snippet(client)
    checks = ["const results = {};"]
    for name, (lat, lng, expected) in QIBLA_REFERENCE.items():
        checks.append(
            f"assert.ok(Math.abs(__calcQibla({lat}, {lng}) - {expected}) < 0.1, "
            f"'{name}: expected ~{expected}, got ' + __calcQibla({lat}, {lng}));"
        )
    _run_node_checks(snippet, "\n".join(checks))


@pytest.mark.skipif(not NODE_AVAILABLE, reason="node not available in this environment")
def test_normalize_heading_wraps_correctly(client):
    snippet = _extract_compass_snippet(client)
    checks = """
    assert.strictEqual(__normalizeHeading(0), 0);
    assert.strictEqual(__normalizeHeading(359), 359);
    assert.strictEqual(__normalizeHeading(360), 0);
    assert.strictEqual(__normalizeHeading(370), 10);      // wraps past 360
    assert.strictEqual(__normalizeHeading(-10), 350);      // negative wraps to positive
    assert.strictEqual(__normalizeHeading(-370), 350);     // large negative
    assert.strictEqual(__normalizeHeading(720), 0);        // multiple full turns
    assert.strictEqual(__normalizeHeading(NaN), null);     // never a fake reading
    assert.strictEqual(__normalizeHeading(undefined), null);
    assert.strictEqual(__normalizeHeading(null), null);
    """
    _run_node_checks(snippet, checks)


@pytest.mark.skipif(not NODE_AVAILABLE, reason="node not available in this environment")
def test_heading_quality_before_any_reading_is_unavailable(client):
    snippet = _extract_compass_snippet(client)
    checks = """
    assert.strictEqual(__getHeadingQuality(), 'unavailable');
    """
    _run_node_checks(snippet, checks)


@pytest.mark.skipif(not NODE_AVAILABLE, reason="node not available in this environment")
def test_heading_quality_ios_source_is_excellent(client):
    snippet = _extract_compass_snippet(client)
    checks = """
    __setHeadingState(true, 'ios', 100);   // fresh reading, 100ms ago
    assert.strictEqual(__getHeadingQuality(), 'excellent');
    """
    _run_node_checks(snippet, checks)


@pytest.mark.skipif(not NODE_AVAILABLE, reason="node not available in this environment")
def test_heading_quality_absolute_alpha_is_good(client):
    snippet = _extract_compass_snippet(client)
    checks = """
    __setHeadingState(true, 'absolute', 100);
    assert.strictEqual(__getHeadingQuality(), 'good');
    """
    _run_node_checks(snippet, checks)


@pytest.mark.skipif(not NODE_AVAILABLE, reason="node not available in this environment")
def test_relative_alpha_without_absolute_flag_is_weak(client):
    """A relative (uncalibrated) heading has no fixed reference and can
    silently drift — it must NOT be reported as 'good', or the confidence
    indicator would be lying to the user about how trustworthy it is."""
    snippet = _extract_compass_snippet(client)
    checks = """
    __setHeadingState(true, 'relative', 100);
    assert.strictEqual(__getHeadingQuality(), 'weak');
    """
    _run_node_checks(snippet, checks)


@pytest.mark.skipif(not NODE_AVAILABLE, reason="node not available in this environment")
def test_stale_reading_degrades_from_excellent_to_weak(client):
    """Master prompt §5 cares about honest state — a reading that stopped
    arriving (locked screen, throttled tab) must not keep showing as
    'excellent' forever on a frozen last value."""
    snippet = _extract_compass_snippet(client)
    checks = """
    __setHeadingState(true, 'ios', 100);
    assert.strictEqual(__getHeadingQuality(), 'excellent');
    __setHeadingState(true, 'ios', 5000);   // same source, but 5s stale
    assert.strictEqual(__getHeadingQuality(), 'weak');
    """
    _run_node_checks(snippet, checks)


@pytest.mark.skipif(not NODE_AVAILABLE, reason="node not available in this environment")
def test_qibla_falls_back_to_resolved_city_when_gps_unavailable(client):
    """The exact gap flagged in AUDIT_REPORT.md §4: if live geolocation is
    denied/unsupported, Qibla must reuse whatever the prayer-times lookup
    already resolved (GPS or a manually-entered city) instead of hard-failing."""
    snippet = _extract_compass_snippet(client)
    lat, lng, expected_bearing = QIBLA_REFERENCE["Cairo"]
    checks = f"""
    __setLastResolvedCoords({{ lat: {lat}, lng: {lng}, source: 'city', label: 'Cairo' }});
    __useResolvedCoordsForQibla('denied');
    const angle = __getQiblaAngle();
    assert.ok(angle !== null, 'qiblaAngle should be set from the fallback coords');
    assert.ok(Math.abs(angle - {expected_bearing}) < 0.1,
      'expected ~{expected_bearing}, got ' + angle);
    """
    _run_node_checks(snippet, checks)


@pytest.mark.skipif(not NODE_AVAILABLE, reason="node not available in this environment")
def test_qibla_fallback_does_not_fabricate_a_bearing_with_nothing_to_fall_back_to(client):
    """No GPS, no prior city lookup either — must fail honestly (leave
    qiblaAngle unset), never show a fake bearing. Master prompt §5:
    'Never show 0° as a valid reading before a real reading exists.'"""
    snippet = _extract_compass_snippet(client)
    checks = """
    __setLastResolvedCoords(null);
    __useResolvedCoordsForQibla('denied');
    assert.strictEqual(__getQiblaAngle(), null);
    """
    _run_node_checks(snippet, checks)
