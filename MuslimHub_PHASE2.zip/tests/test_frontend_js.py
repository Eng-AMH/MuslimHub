"""
Renders real pages and syntax-checks their *actual rendered* inline <script>
content with Node. This catches two classes of bug in one pass:
  - Jinja errors (the page wouldn't render at all)
  - JS typos/syntax errors in template-embedded scripts, which a plain
    Python import/AST check (tools/verify_muslimhub.py) can never see because
    it never looks inside .html files.

Requires `node` on PATH; skips (not fails) if it's unavailable, since Node
is a dev-time nicety here, not a runtime dependency of the Flask app itself.
"""
import re
import shutil
import subprocess
import tempfile
import os
import pytest

NODE_AVAILABLE = shutil.which('node') is not None

PAGES_WITH_NONTRIVIAL_JS = [
    '/', '/audio/', '/prayer/', '/quran/1', '/settings', '/chat/',
    '/auth/login', '/auth/signup', '/memorial/',
]


def _extract_inline_scripts(html):
    # Only inline <script>...</script> blocks (no src=) — external files are
    # checked directly elsewhere and aren't part of the rendered HTML anyway.
    return re.findall(r'<script(?![^>]*\bsrc=)[^>]*>(.*?)</script>', html, re.DOTALL)


@pytest.mark.skipif(not NODE_AVAILABLE, reason="node not available in this environment")
@pytest.mark.parametrize("path", PAGES_WITH_NONTRIVIAL_JS)
def test_rendered_inline_js_has_no_syntax_errors(client, path):
    resp = client.get(path)
    assert resp.status_code < 500, f"{path} failed to render (status {resp.status_code})"
    html = resp.data.decode('utf-8', 'ignore')
    scripts = _extract_inline_scripts(html)
    if not scripts:
        return

    combined = "\n;\n".join(scripts)  # `;` separator guards against a missing
                                        # trailing semicolon merging blocks badly
    with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
        f.write(combined)
        tmp_path = f.name
    try:
        result = subprocess.run(
            ['node', '--check', tmp_path],
            capture_output=True, text=True, timeout=10,
        )
        assert result.returncode == 0, (
            f"Syntax error in {path}'s inline JS:\n{result.stderr}"
        )
    finally:
        os.unlink(tmp_path)


@pytest.mark.skipif(not NODE_AVAILABLE, reason="node not available in this environment")
@pytest.mark.parametrize("path", ['static/sw.js', 'static/js/quran-audio.js'])
def test_static_js_files_have_no_syntax_errors(path):
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    full_path = os.path.join(root, path)
    result = subprocess.run(['node', '--check', full_path], capture_output=True, text=True, timeout=10)
    assert result.returncode == 0, f"Syntax error in {path}:\n{result.stderr}"
