from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_wtf import CSRFProtect

db = SQLAlchemy()
login_manager = LoginManager()
login_manager.login_view = 'auth.login'
login_manager.login_message = 'يرجى تسجيل الدخول للمتابعة'
login_manager.login_message_category = 'info'

# Shared CSRF protection. Initialized against the app in app.py:create_app().
# NOTE: this was previously never initialized anywhere, which meant:
#   1) the `csrf_token()` Jinja global used by 12 admin templates did not exist,
#      crashing every admin list/form page as soon as it had to render a row
#      (see AUDIT_REPORT.md — this was the single biggest bug found in audit).
#   2) no non-admin form or fetch() call in the app was actually CSRF-protected.
csrf = CSRFProtect()
