from flask import Flask, session, current_app, send_from_directory, abort, request, g
from app_init import db, login_manager, csrf
from config import Config
from datetime import datetime
import os
import json


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    db.init_app(app)
    login_manager.init_app(app)
    csrf.init_app(app)

    # A missing/expired CSRF token should fail politely (flash + redirect back),
    # not surface Flask-WTF's raw 400 page to a normal visitor whose session
    # simply timed out on a long-open tab.
    from flask_wtf.csrf import CSRFError
    from flask import flash, redirect

    @app.errorhandler(CSRFError)
    def handle_csrf_error(e):
        flash(
            'انتهت صلاحية الجلسة أو الطلب غير صالح — يرجى إعادة المحاولة.'
            if session.get('lang', 'ar') == 'ar'
            else 'Your session expired or the request was invalid — please try again.',
            'error'
        )
        nxt = request.referrer or '/'
        return redirect(nxt)

    # ── Flask-Limiter (brute-force / flood protection) ──────────────────────
    from flask_limiter import Limiter
    from flask_limiter.util import get_remote_address
    limiter = Limiter(
        get_remote_address,
        app=app,
        default_limits=["200 per day", "50 per hour"],
        storage_uri="memory://",
    )
    app.extensions['limiter'] = limiter

    @login_manager.user_loader
    def load_user(user_id):
        from models import User
        try:
            return User.query.get(int(user_id))
        except Exception:
            return None

    # ── Blueprints ──────────────────────────────────────────────────────────
    from routes.main       import main_bp
    from routes.auth       import auth_bp
    from routes.user       import user_bp
    from routes.quran      import quran_bp
    from routes.audio      import audio_bp
    from routes.adhkar     import adhkar_bp
    from routes.tasbeeh    import tasbeeh_bp
    from routes.duas       import duas_bp
    from routes.hadith     import hadith_bp
    from routes.memorial   import memorial_bp
    from routes.prayer     import prayer_bp
    from routes.chat       import chat_bp
    from routes.good_deeds import good_deeds_bp
    from routes.admin      import admin_bp
    from routes.api        import api_bp

    app.register_blueprint(main_bp)
    app.register_blueprint(auth_bp,       url_prefix='/auth')
    app.register_blueprint(user_bp,       url_prefix='/user')
    app.register_blueprint(quran_bp,      url_prefix='/quran')
    app.register_blueprint(audio_bp,      url_prefix='/audio')
    app.register_blueprint(adhkar_bp,     url_prefix='/adhkar')
    app.register_blueprint(tasbeeh_bp,    url_prefix='/tasbeeh')
    app.register_blueprint(duas_bp,       url_prefix='/duas')
    app.register_blueprint(hadith_bp,     url_prefix='/hadith')
    app.register_blueprint(memorial_bp,   url_prefix='/memorial')
    app.register_blueprint(prayer_bp,     url_prefix='/prayer')
    app.register_blueprint(chat_bp,       url_prefix='/chat')
    app.register_blueprint(good_deeds_bp, url_prefix='/good-deeds')
    app.register_blueprint(admin_bp,      url_prefix='/admin')
    app.register_blueprint(api_bp,        url_prefix='/api')

    # Apply stricter rate limits on auth endpoints
    limiter.limit("10 per minute")(auth_bp)

    # ── Context processor ───────────────────────────────────────────────────
    @app.context_processor
    def inject_globals():
        from flask_login import current_user

        lang  = session.get('lang', 'ar')
        theme = session.get('theme', 'light')

        unread_msgs   = 0
        unread_notifs = 0

        if current_user.is_authenticated:
            try:
                unread_msgs = current_user.unread_msgs()
            except Exception:
                unread_msgs = 0
            try:
                unread_notifs = current_user.unread_notifs()
            except Exception:
                unread_notifs = 0

        return dict(
            current_lang=lang,
            current_theme=theme,
            site_name='Muslim Hub',
            now=datetime.utcnow(),
            current_user=current_user,
            unread_msgs=unread_msgs,
            unread_notifs=unread_notifs,
        )

    # ── before_request: throttled last_seen ────────────────────────────────
    @app.before_request
    def update_last_seen():
        from flask_login import current_user
        if current_user.is_authenticated:
            now  = datetime.utcnow()
            last = session.get('last_seen_ts', 0)
            if now.timestamp() - last > 300:   # write at most once per 5 min
                current_user.last_seen = now
                db.session.commit()
                session['last_seen_ts'] = now.timestamp()

    # ── Security headers ────────────────────────────────────────────────────
    @app.after_request
    def set_security_headers(response):
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options']        = 'SAMEORIGIN'
        response.headers['Referrer-Policy']        = 'strict-origin-when-cross-origin'
        response.headers['Permissions-Policy']     = (
            'geolocation=(self), accelerometer=(self), gyroscope=(self), magnetometer=(self), ' 
            'camera=(), microphone=()'
        )
        # Content-Security-Policy — moderate; tightened once SocketIO is removed
        response.headers['Content-Security-Policy'] = (
            "default-src 'self'; "
            "script-src 'self' 'unsafe-inline'; "
            "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
            "font-src 'self' https://fonts.gstatic.com; "
            "img-src 'self' data: https:; "
            "media-src 'self' https://cdn.islamic.network https://www.everyayah.com; "
            "connect-src 'self' https://api.alquran.cloud https://api.aladhan.com "
            "https://cdn.islamic.network https://www.everyayah.com; "
            "frame-ancestors 'self';"
        )
        return response

    # ── Static helpers ──────────────────────────────────────────────────────
    @app.route('/robots.txt')
    def robots():
        path = os.path.join(current_app.static_folder, 'robots.txt')
        if not os.path.exists(path):
            abort(404)
        return send_from_directory(
            current_app.static_folder, 'robots.txt',
            mimetype='text/plain; charset=utf-8'
        )

    @app.route('/sitemap.xml')
    def sitemap():
        path = os.path.join(current_app.static_folder, 'sitemap.xml')
        if not os.path.exists(path):
            abort(404)
        return send_from_directory(
            current_app.static_folder, 'sitemap.xml',
            mimetype='application/xml; charset=utf-8'
        )

    # ── DB / seed ───────────────────────────────────────────────────────────
    with app.app_context():
        if os.environ.get("INIT_DB_ON_STARTUP", "1") == "1":
            try:
                db.create_all()
                _seed_admin()
                _seed_reciters()
                _seed_content()
            except Exception:
                app.logger.exception("Database initialization failed")

    return app


# ── Seed helpers ────────────────────────────────────────────────────────────

def _seed_admin():
    from models import Admin
    from config import Config
    cfg = Config()
    if not Admin.query.filter_by(username=cfg.ADMIN_USERNAME).first():
        a = Admin(username=cfg.ADMIN_USERNAME, email=cfg.ADMIN_EMAIL, role='super_admin')
        a.set_password(cfg.ADMIN_PASSWORD)
        db.session.add(a)
        db.session.commit()



def _seed_reciters():
    """
    Insert / repair reciters in the database.

    CDN FORMAT RULE — cdn.islamic.network uses IDENTICAL key format for both
    ayah-level and surah-level audio:   ar.IDENTIFIER
    e.g.  ar.alafasy   ar.abdurrahmaansudais   ar.husary

    The OLD mp3quran.net format (Alafasy_128kbps, Husary_128kbps …) is NOT
    served by cdn.islamic.network and will always 404 at play time.

    This function:
      1. Migrates any existing records that still use the old format.
      2. Normalizes the canonical 14-reciter list.
      3. Deactivates any non-canonical leftovers so the UI only shows working
         reciters.
    """
    from models import Reciter

    # Canonical list used by the current audio player / CDN.
    # (name_ar, name_en, cdn_key, style, order_num)
    RECITERS = [
        ('مشاري راشد العفاسي',         'Mishary Rashid Alafasy',           'ar.alafasy',              'مرتل',  1),
        ('عبدالرحمن السديس',           'Abdurrahman Al-Sudais',            'ar.abdurrahmaansudais',   'مرتل',  2),
        ('ماهر المعيقلي',              'Maher Al-Muaiqly',                 'ar.mahermuaiqly',         'مرتل',  3),
        ('أبو بكر الشاطري',            'Abu Bakr Al-Shatri',               'ar.shaatree',             'مرتل',  4),
        ('سعد الغامدي',                'Saad Al-Ghamdi',                   'ar.saadalghamdi',         'مرتل',  5),
        ('عبد الباسط عبد الصمد (مرتل)', 'Abdul Basit (Murattal)',           'ar.abdulbasitmurattal',   'مرتل',  6),
        ('محمود خليل الحصري',          'Mahmoud Khalil Al-Husary',         'ar.husary',               'مرتل',  7),
        ('محمد صديق المنشاوي',         'Muhammad Siddiq Al-Minshawi',      'ar.minshawi',             'مرتل',  8),
        ('أحمد بن علي العجمي',         'Ahmed ibn Ali Al-Ajamy',           'ar.ahmedajamy',           'مرتل',  9),
        ('هاني الرفاعي',               'Hani Al-Rifai',                    'ar.hanirifai',            'مرتل', 10),
        ('علي بن عبدالرحمن الحذيفي',   'Ali Al-Hudhaifi',                  'ar.hudhaify',             'مرتل', 11),
        ('عبد الله بصفر',              'Abdullah Basfar',                  'ar.abdullahbasfar',       'مرتل', 12),
        ('محمود خليل الحصري (مجوّد)',   'Al-Husary (Mujawwad)',             'ar.husarymujawwad',       'مجوّد', 13),
        ('عبد الباسط عبد الصمد (مجوّد)', 'Abdul Basit (Mujawwad)',          'ar.abdulbasitmujawwad',   'مجوّد', 14),
    ]
    canonical_by_key = {cdn_key: (name_ar, name_en, style, order_num) for name_ar, name_en, cdn_key, style, order_num in RECITERS}
    canonical_keys = set(canonical_by_key)

    # Old / legacy keys we may find in already-deployed databases.
    OLD_TO_NEW = {
        'Alafasy_128kbps':                               'ar.alafasy',
        'Alafasy_64kbps':                                'ar.alafasy',
        'Abdurrahmaan_As-Sudais_192kbps':                'ar.abdurrahmaansudais',
        'Abdurrahmaan_As-Sudais_128kbps':                'ar.abdurrahmaansudais',
        'Maher_128kbps':                                 'ar.mahermuaiqly',
        'Maher_AlMuaiqly_128kbps':                       'ar.mahermuaiqly',
        'Abu_Bakr_Ash-Shaatree_128kbps':                 'ar.shaatree',
        'Shaatree_128kbps':                              'ar.shaatree',
        'Ghamadi_40kbps':                                'ar.saadalghamdi',
        'Saad_Ghamdi_128kbps':                           'ar.saadalghamdi',
        'AbdulSamad_128kbps_ketaballah.com':             'ar.abdulbasitmurattal',
        'AbdulBaset_128kbps':                            'ar.abdulbasitmurattal',
        'Abdul_Basit_Mujawwad_128kbps':                  'ar.abdulbasitmujawwad',
        'AbdulSamad_Mujawwad_128kbps':                   'ar.abdulbasitmujawwad',
        'Husary_128kbps':                                'ar.husary',
        'Husary_64kbps':                                 'ar.husary',
        'Husary_Mujawwad_128kbps':                       'ar.husarymujawwad',
        'Minshawi_128kbps':                              'ar.minshawi',
        'Minshawy_Murattal_128kbps':                     'ar.minshawi',
        'Ahmed_ibn_Ali_al-Ajamy_128kbps_ketaballah.com': 'ar.ahmedajamy',
        'AhmedAlAjamy_128kbps':                          'ar.ahmedajamy',
        'Hani_Rifai_192kbps':                            'ar.hanirifai',
        'Ali_Alhuthaify_128kbps':                        'ar.hudhaify',
        'Hudhaify_128kbps':                              'ar.hudhaify',
        'Abdullah_Basfar_192kbps':                       'ar.abdullahbasfar',
        'Saud_ash-Shuraym_128kbps':                      'ar.saadalghamdi',
        'Nasser_Alqatami_128kbps':                       None,
        'Yasser_Ad-Dussary_128kbps':                     None,
        'Fares_Abbad_64kbps':                            None,
        'Idrees_Abkar_128kbps':                          None,
        'Khalid_Abdulkafi_128kbps':                      None,
        'Muhammad_Jibreel_128kbps':                      None,
        'Sahl_Yassin_128kbps':                           None,
        'Faisal_Saleh_128kbps':                          None,
    }

    changed = False

    # 1) Migrate old-format keys already stored in the DB.
    for old_key, new_key in OLD_TO_NEW.items():
        rows = Reciter.query.filter_by(cdn_key=old_key).all()
        for row in rows:
            changed = True
            if new_key is None:
                row.is_active = False
                continue

            existing = Reciter.query.filter_by(cdn_key=new_key).first()
            if existing and existing.id != row.id:
                # Keep the canonical row, remove the duplicate legacy row.
                db.session.delete(row)
            else:
                row.cdn_key = new_key

    # 2) Normalize the canonical list: update names/order/style and ensure each
    #    canonical key exists exactly once and is active.
    for name_ar, name_en, cdn_key, style, order_num in RECITERS:
        row = Reciter.query.filter_by(cdn_key=cdn_key).first()
        if row:
            if (
                row.name_ar != name_ar
                or row.name_en != name_en
                or row.style != style
                or row.order_num != order_num
                or not row.is_active
            ):
                row.name_ar = name_ar
                row.name_en = name_en
                row.style = style
                row.order_num = order_num
                row.is_active = True
                changed = True
        else:
            db.session.add(Reciter(
                name_ar=name_ar,
                name_en=name_en,
                cdn_key=cdn_key,
                style=style,
                order_num=order_num,
                is_active=True,
            ))
            changed = True

    # 3) Deactivate any leftovers that are not part of the supported list.
    extras = Reciter.query.filter(
        db.or_(
            Reciter.cdn_key.is_(None),
            ~Reciter.cdn_key.in_(canonical_keys),
        )
    ).all()
    for row in extras:
        if row.is_active:
            row.is_active = False
            changed = True

    if changed:
        db.session.commit()

def _seed_content():
    from models import Dhikr, Duaa, Hadith
    data_dir = os.path.join(os.path.dirname(__file__), 'data')

    if Dhikr.query.count() == 0:
        p = os.path.join(data_dir, 'adhkar.json')
        if os.path.exists(p):
            with open(p, encoding='utf-8') as f:
                for item in json.load(f):
                    db.session.add(Dhikr(**item))
            db.session.commit()

    if Duaa.query.count() == 0:
        p = os.path.join(data_dir, 'duas.json')
        if os.path.exists(p):
            with open(p, encoding='utf-8') as f:
                for item in json.load(f):
                    db.session.add(Duaa(**item))
            db.session.commit()

    if Hadith.query.count() == 0:
        p = os.path.join(data_dir, 'hadith.json')
        if os.path.exists(p):
            with open(p, encoding='utf-8') as f:
                for item in json.load(f):
                    db.session.add(Hadith(**item))
            db.session.commit()


app = create_app()
application = app

if __name__ == '__main__':
    app.run(debug=app.config['DEBUG'], host='0.0.0.0',
            port=int(os.environ.get('PORT', 5000)))