"""
Run this script from PythonAnywhere bash to reseed adhkar and duas:
  python reseed_content.py

WARNING: This will DELETE all existing Dhikr and Duaa rows and reload from JSON.
Custom entries added via admin will be lost.
"""
import os, json, sys

# Make sure we can import the app
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import create_app
from app_init import db

app = create_app()

with app.app_context():
    from models import Dhikr, Duaa

    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

    # ── Dhikr ────────────────────────────────────────────────────────────────
    p = os.path.join(data_dir, 'adhkar.json')
    if os.path.exists(p):
        print(f"Deleting {Dhikr.query.count()} existing dhikr rows...")
        Dhikr.query.delete()
        db.session.commit()
        with open(p, encoding='utf-8') as f:
            items = json.load(f)
        for item in items:
            db.session.add(Dhikr(**item))
        db.session.commit()
        print(f"✅ Seeded {len(items)} dhikr entries.")
    else:
        print("❌ data/adhkar.json not found.")

    # ── Duaa ─────────────────────────────────────────────────────────────────
    p = os.path.join(data_dir, 'duas.json')
    if os.path.exists(p):
        print(f"Deleting {Duaa.query.count()} existing duaa rows...")
        Duaa.query.delete()
        db.session.commit()
        with open(p, encoding='utf-8') as f:
            items = json.load(f)
        for item in items:
            db.session.add(Duaa(**item))
        db.session.commit()
        print(f"✅ Seeded {len(items)} duaa entries.")
    else:
        print("❌ data/duas.json not found.")

    print("\nDone! Reload your web app.")
