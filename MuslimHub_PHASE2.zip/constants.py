"""
Centralised constants shared across routes.
Import from here instead of re-defining in each blueprint.
"""

# ── Avatars ───────────────────────────────────────────────────────────────────
AVATARS = [
    '🧕', '👳', '🌙', '☪️', '📿', '🕌', '🌿', '🤲',
    '☀️', '⭐', '🌺', '🦋', '🤍', '🌸', '🌼', '🌚', '🌝', '🕊️',
]

# ── Adhkar categories ─────────────────────────────────────────────────────────
ADHKAR_CATEGORIES = {
    'morning':      {'ar': 'أذكار الصباح',         'en': 'Morning Adhkar',     'icon': '🌅'},
    'evening':      {'ar': 'أذكار المساء',          'en': 'Evening Adhkar',     'icon': '🌇'},
    'sleep':        {'ar': 'أذكار النوم',            'en': 'Sleep Adhkar',       'icon': '🌙'},
    'waking':       {'ar': 'أذكار الاستيقاظ',       'en': 'Waking Up Adhkar',   'icon': '☀️'},
    'after_prayer': {'ar': 'أذكار بعد الصلاة',      'en': 'After Prayer',       'icon': '🕌'},
    'travel':       {'ar': 'أذكار السفر',            'en': 'Travel Adhkar',      'icon': '✈️'},
    'home':         {'ar': 'أذكار المنزل',           'en': 'Home Adhkar',        'icon': '🏠'},
    'eating':       {'ar': 'أذكار الطعام',           'en': 'Eating Adhkar',      'icon': '🍽️'},
    'protection':   {'ar': 'الحماية والتحصين',      'en': 'Protection',         'icon': '🛡️'},
    'healing':      {'ar': 'الشفاء من المرض',        'en': 'Healing',            'icon': '💊'},
    'repentance':   {'ar': 'التوبة والاستغفار',      'en': 'Repentance',         'icon': '🌿'},
    'parents':      {'ar': 'الدعاء للوالدين',        'en': 'Dua for Parents',    'icon': '❤️'},
    'funeral':      {'ar': 'الجنائز والمرحومين',     'en': 'Funeral Adhkar',     'icon': '💚'},
    'relief':       {'ar': 'الكرب والفرج',           'en': 'Relief & Ease',      'icon': '🌤️'},
}

# ── Duas categories ───────────────────────────────────────────────────────────
DUAS_CATEGORIES = {
    'parents':    {'ar': 'الوالدين',       'en': 'Parents'},
    'deceased':   {'ar': 'المتوفين',       'en': 'Deceased'},
    'healing':    {'ar': 'الشفاء',         'en': 'Healing'},
    'provision':  {'ar': 'الرزق',          'en': 'Provision'},
    'guidance':   {'ar': 'الهداية',        'en': 'Guidance'},
    'forgiveness':{'ar': 'المغفرة',        'en': 'Forgiveness'},
    'anxiety':    {'ar': 'الهم والحزن',    'en': 'Anxiety & Grief'},
    'travel':     {'ar': 'السفر',          'en': 'Travel'},
    'gratitude':  {'ar': 'الشكر',          'en': 'Gratitude'},
    'protection': {'ar': 'الحماية',        'en': 'Protection'},
    'exam':       {'ar': 'الامتحانات',     'en': 'Exams'},
    'marriage':   {'ar': 'الزواج',         'en': 'Marriage'},
    'hardship':   {'ar': 'الشدة',          'en': 'Hardship'},
}

# ── Hadith categories ─────────────────────────────────────────────────────────
HADITH_CATEGORIES = {
    'iman':      {'ar': 'الإيمان',         'en': 'Faith'},
    'salah':     {'ar': 'الصلاة',          'en': 'Prayer'},
    'akhlaq':    {'ar': 'الأخلاق',         'en': 'Character'},
    'duaa':      {'ar': 'الدعاء والذكر',   'en': 'Duaa & Dhikr'},
    'quran':     {'ar': 'القرآن الكريم',   'en': 'Quran'},
    'family':    {'ar': 'الأسرة',          'en': 'Family'},
    'society':   {'ar': 'المجتمع',         'en': 'Society'},
    'knowledge': {'ar': 'العلم',           'en': 'Knowledge'},
    'tawbah':    {'ar': 'التوبة',          'en': 'Repentance'},
    'ramadan':   {'ar': 'رمضان',           'en': 'Ramadan'},
    'general':   {'ar': 'عام',             'en': 'General'},
}

# ── Valid themes ───────────────────────────────────────────────────────────────
VALID_THEMES = {'light', 'dark', 'mishkah'}
