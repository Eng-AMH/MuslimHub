# Muslim Hub — Implementation Report

This is a running log, updated at the end of each phase, per Master Prompt §66.
It records exactly what changed — not a claim of overall completeness. See
`AUDIT_REPORT.md` for the full audit and the phase roadmap.

---

## Phase 1 — Audit + regression baseline

**Already working (verified, not assumed):** Quran text/audio, prayer times,
Qibla/compass, adhkar/duas/hadith/tasbeeh, memorial, the social layer
(friends/DMs/notifications), group chat, PWA shell. No SQL-injection surface,
no dangerous code patterns (`eval`/`exec`/`pickle`/etc.) anywhere.

**Broken, found via actually booting the app and testing against real data
(not static analysis):** `CSRFProtect` was never initialized, so `csrf_token()`
— called by 12 admin templates — was an undefined Jinja global. Any admin page
rendering a row of real content crashed with a 500. Confirmed against your
actual `instance/muslimhub.db` (41 duas, 75 adhkar, 33 reciters, etc.), not a
fresh/empty test database.

**Fixed:**
- `app_init.py` — added a shared `CSRFProtect` instance
- `app.py` — initialized it in `create_app()`; added a friendly `CSRFError` handler (flash + redirect, not a raw 400 page)
- `templates/base.html` — global `<meta name="csrf-token">` + `CSRF_TOKEN` JS constant
- 9 templates — added the missing `{{ csrf_token() }}` hidden field to every server-rendered POST form: `auth/login.html`, `auth/signup.html`, `auth/change_password.html`, `admin/login.html`, `memorial/index.html` (×2 forms), `user/conversation.html`, `user/edit_profile.html`, `user/friends.html` (×3), `user/profile.html` (×3)
- `templates/chat/index.html`, `templates/user/profile.html`, `templates/user/search.html` — added the `X-CSRFToken` header to every JS `fetch()` POST call

**Files added:** `tests/` (conftest.py, test_smoke.py, test_csrf_protection.py) — 39 tests.

**Not touched / needs your action:** the leaked admin credential in `DEPLOY.md` — rotating it isn't something I can do on your behalf.

---

## Phase 2 — Quran audio + Qibla (this pass)

Scope: close the specific gaps `AUDIT_REPORT.md` §4 identified in the two
subsystems that were already strong, rather than rebuilding them.

### Added: Admin Audio Health Monitor (master prompt §2, §29 — was 0% built)

| File | Change |
|---|---|
| `models.py` | New `AudioHealthCheck` model — keeps history per reciter, not just a last-status flag |
| `services/audio_service.py` | **New file.** `check_reciter_audio()` mirrors the client engine's exact bitrate fallback order (`static/js/quran-audio.js`'s `BITRATES`), so a health check reports what a real listener would actually experience. Distinguishes `healthy` (preferred bitrate works) from `warning` (only a fallback bitrate works) from `broken` (nothing works) — master prompt §29: "Never silently expose a broken reciter as healthy" |
| `routes/admin.py` | New `POST /admin/reciters/test/<id>` route; `reciters()` now loads each reciter's latest check |
| `templates/admin/reciters.html` | New "🩺 Test" button + status badge column per reciter |
| `static/css/style.css`, `templates/admin/base_admin.html`, `templates/base.html` | Small fix found while wiring this up: the admin flash-message system had no styling for a "warning" category and didn't distinguish error from info by icon — fixed for all admin flashes, not just the new ones |

**Known limitation, stated plainly:** this sandbox's network allowlist doesn't
include `cdn.islamic.network`, so the actual HTTP probe logic is tested with
the network layer mocked (`tests/test_audio_service.py`), not against the real
CDN. The code path is real and will make real requests once deployed; live
reachability just couldn't be verified from here. Smoke-test this once
deployed by clicking "Test" on a couple of reciters.

### Fixed: offline audio download (was scaffolded but broken + unreachable)

- `static/sw.js` — `CACHE_AUDIO_SURAH` handler no longer hardcodes 128kbps (was silently caching nothing for reciters needing a different bitrate); now accepts a known-working bitrate or falls back through the same list the player uses, and replies with success/failure so the UI isn't guessing
- `static/js/quran-audio.js` — added `getCurrentBitrate()` so the UI can ask the engine which bitrate is actually confirmed working
- `templates/audio/index.html` — new 📥 "save for offline" button in the player, using the confirmed-working bitrate

### Fixed: Qibla gaps

- `templates/prayer/index.html` — `findQibla()` now falls back to whatever location the prayer-times lookup already resolved (GPS or a manually-entered city) when live geolocation is denied/unsupported, instead of hard-failing (master prompt §5: "no hard failure if location is denied"). The status text is honest about it being approximate ("(تقريبي، من مدينة...)") rather than presenting a city-derived bearing as GPS-precise
- Added the excellent/good/weak/unavailable heading-confidence indicator §5 asks for, based on which real sensor API supplied the reading (iOS `webkitCompassHeading` → excellent, absolute `deviceorientationabsolute`/`alpha` → good, relative-only alpha → weak — it has no fixed reference and can drift) plus staleness (a reading that stops arriving degrades rather than staying "excellent" forever on a frozen value)

### Testing added this phase

- `tests/test_audio_service.py` (10 tests) — bitrate fallback logic, HEAD→ranged-GET fallback for CDN nodes that reject HEAD, timeout/connection-error handling, all with the HTTP layer mocked
- `tests/test_admin_audio_health.py` (5 tests) — route requires admin auth + CSRF, stores results correctly, history accumulates rather than being overwritten, a broken reciter is never hidden
- `tests/test_frontend_js.py` (11 tests) — renders real pages through Flask and syntax-checks the *actual rendered* inline JS with Node; catches Jinja errors and JS typos in the same pass. Skips gracefully if `node` isn't on PATH
- `tests/test_qibla_compass_logic.py` (9 tests) — extracts the real compass JS from the rendered `/prayer/` page (not a hand-copied duplicate that could drift) and executes it under Node: angle wrap-around, the great-circle Qibla bearing formula checked against an independently-computed Python reference for four cities, and the new confidence-indicator and city-fallback logic. Also caught a real gap in my own manual code reading during development — a multi-line top-level statement a text scan missed — which is exactly the kind of thing this suite exists to catch going forward

**Total suite: 74 tests, all passing**, including a fresh extraction from a copy of your real `instance/muslimhub.db` confirming the new `AudioHealthCheck` table auto-creates via the existing `db.create_all()` startup path without touching any existing table or row.

**Added:** `requirements-dev.txt` (pytest — needed to run `tests/`, not a runtime dependency of the app itself). `node` is used by two test files for JS verification; those tests skip (not fail) if it's absent.

### Not done in Phase 2 (explicitly deferred, not silently skipped)

- Explicit `offline`/`blocked-by-browser` states in the JS audio engine's state machine (currently folded into generic error handling) — real gap, deferred to keep this phase's scope honest rather than rushed
- Bulk "download this reciter's full Quran for offline" UI in Settings — the per-surah download from the player (this phase) is real and complete; a reciter-level bulk picker is a larger, separate UI addition
- `/admin/reciters` `_validate_admin_csrf()` and the global CSRFProtect hook now both run on every admin POST (harmless — confirmed by test — but redundant); worth removing the now-superseded manual checks in a later cleanup pass, not urgent

---

## Cumulative file changes (Phases 1–2)

**New files:** `services/__init__.py`, `services/audio_service.py`, `requirements-dev.txt`, `tests/` (7 files), `AUDIT_REPORT.md`, `IMPLEMENTATION_REPORT.md`

**Modified:** `app.py`, `app_init.py`, `models.py`, `routes/admin.py`, `static/css/style.css`, `static/sw.js`, `static/js/quran-audio.js`, `templates/base.html`, `templates/admin/base_admin.html`, `templates/admin/reciters.html`, `templates/audio/index.html`, `templates/prayer/index.html`, and the 9 CSRF-token-added templates listed under Phase 1

**Database:** one new table (`audio_health_check`), additive-only, confirmed safe against real data (see above). No existing table altered.

**Unresolved / outstanding:**
1. Leaked admin credential in `DEPLOY.md` — needs rotation (your action, flagged since Phase 1)
2. Audio health-check HTTP logic untested against the real CDN (network-restricted sandbox)
3. Everything in `AUDIT_REPORT.md`'s feature map still marked ❌ (Adhan engine, Wallpaper system, Desktop Companion, Islamic events, unified reminders, Saved Moments, Daily Intent, Deen Mode) — unchanged this phase, by design, since Phase 2 was scoped to audio + Qibla only
