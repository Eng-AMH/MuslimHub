from app_init import db
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin

# ═══ USER & SOCIAL ════════════════════════════════════════════════════════════

class User(UserMixin, db.Model):
    __tablename__ = 'user'
    id            = db.Column(db.Integer, primary_key=True)
    username      = db.Column(db.String(40),  unique=True, nullable=False, index=True)
    display_name  = db.Column(db.String(80))
    email         = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(256), nullable=False)
    bio           = db.Column(db.String(300))
    avatar        = db.Column(db.String(10), default='🧕')
    privacy       = db.Column(db.String(10), default='public')   # public/friends/private
    is_active     = db.Column(db.Boolean, default=True)
    is_banned     = db.Column(db.Boolean, default=False)
    role          = db.Column(db.String(15), default='user')      # user/moderator/admin
    last_seen     = db.Column(db.DateTime, default=datetime.utcnow)
    created_at    = db.Column(db.DateTime, default=datetime.utcnow)

    sent_requests     = db.relationship('Friendship', foreign_keys='Friendship.requester_id',
                                         backref='requester', lazy='dynamic')
    received_requests = db.relationship('Friendship', foreign_keys='Friendship.addressee_id',
                                         backref='addressee', lazy='dynamic')
    sent_messages     = db.relationship('PrivateMessage', foreign_keys='PrivateMessage.sender_id',
                                         backref='sender', lazy='dynamic')
    received_messages = db.relationship('PrivateMessage', foreign_keys='PrivateMessage.receiver_id',
                                         backref='receiver', lazy='dynamic')
    notifications     = db.relationship('Notification', backref='user', lazy='dynamic')

    def set_password(self, pw):   self.password_hash = generate_password_hash(pw)
    def check_password(self, pw): return check_password_hash(self.password_hash, pw)
    def get_name(self):           return self.display_name or self.username

    def is_friends_with(self, other):
        return Friendship.query.filter(
            db.or_(
                db.and_(Friendship.requester_id == self.id,  Friendship.addressee_id == other.id),
                db.and_(Friendship.requester_id == other.id, Friendship.addressee_id == self.id),
            ),
            Friendship.status == 'accepted',
        ).first() is not None

    def friendship_with(self, other):
        return Friendship.query.filter(
            db.or_(
                db.and_(Friendship.requester_id == self.id,  Friendship.addressee_id == other.id),
                db.and_(Friendship.requester_id == other.id, Friendship.addressee_id == self.id),
            )
        ).first()

    def unread_msgs(self):
        return PrivateMessage.query.filter_by(receiver_id=self.id, is_read=False).count()

    def unread_notifs(self):
        return Notification.query.filter_by(user_id=self.id, is_read=False).count()

    @property
    def friends(self):
        """Return friend User objects using a single JOIN — no N+1."""
        from sqlalchemy import case
        friend_ids = db.session.query(
            db.case(
                (Friendship.requester_id == self.id, Friendship.addressee_id),
                else_=Friendship.requester_id,
            )
        ).filter(
            db.or_(
                Friendship.requester_id == self.id,
                Friendship.addressee_id == self.id,
            ),
            Friendship.status == 'accepted',
        ).all()
        ids = [r[0] for r in friend_ids]
        if not ids:
            return []
        return User.query.filter(User.id.in_(ids)).all()


class Friendship(db.Model):
    __tablename__ = 'friendship'
    id           = db.Column(db.Integer, primary_key=True)
    requester_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    addressee_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    status       = db.Column(db.String(10), default='pending', index=True)  # ← indexed
    created_at   = db.Column(db.DateTime, default=datetime.utcnow)
    __table_args__ = (db.UniqueConstraint('requester_id', 'addressee_id'),)


class PrivateMessage(db.Model):
    __tablename__ = 'private_message'
    id          = db.Column(db.Integer, primary_key=True)
    sender_id   = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    body        = db.Column(db.Text, nullable=False)
    msg_type    = db.Column(db.String(15), default='text')
    is_read     = db.Column(db.Boolean, default=False, index=True)   # ← indexed
    created_at  = db.Column(db.DateTime, default=datetime.utcnow)


class Notification(db.Model):
    __tablename__ = 'notification'
    id         = db.Column(db.Integer, primary_key=True)
    user_id    = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    type       = db.Column(db.String(30))
    message    = db.Column(db.String(300))
    link       = db.Column(db.String(200))
    is_read    = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Report(db.Model):
    __tablename__ = 'report'
    id          = db.Column(db.Integer, primary_key=True)
    reporter_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    target_type = db.Column(db.String(20))
    target_id   = db.Column(db.Integer)
    reason      = db.Column(db.String(200))
    status      = db.Column(db.String(15), default='open')
    created_at  = db.Column(db.DateTime, default=datetime.utcnow)


# ═══ CONTENT ══════════════════════════════════════════════════════════════════

class Duaa(db.Model):
    __tablename__ = 'duaa'
    id                   = db.Column(db.Integer, primary_key=True)
    title_ar             = db.Column(db.String(200), nullable=False)
    title_en             = db.Column(db.String(200))
    text_ar              = db.Column(db.Text, nullable=False)
    text_en              = db.Column(db.Text)
    text_transliteration = db.Column(db.Text)
    category             = db.Column(db.String(50), nullable=False, index=True)
    source               = db.Column(db.String(200))
    is_featured          = db.Column(db.Boolean, default=False)
    order_num            = db.Column(db.Integer, default=0)
    created_at           = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at           = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Dhikr(db.Model):
    __tablename__ = 'dhikr'
    id                   = db.Column(db.Integer, primary_key=True)
    title_ar             = db.Column(db.String(200), nullable=False)
    title_en             = db.Column(db.String(200))
    text_ar              = db.Column(db.Text, nullable=False)
    text_en              = db.Column(db.Text)
    text_transliteration = db.Column(db.Text)
    category             = db.Column(db.String(50), nullable=False, index=True)
    repetitions          = db.Column(db.Integer, default=1)
    source               = db.Column(db.String(200))
    order_num            = db.Column(db.Integer, default=0)
    created_at           = db.Column(db.DateTime, default=datetime.utcnow)


class Hadith(db.Model):
    __tablename__ = 'hadith'
    id          = db.Column(db.Integer, primary_key=True)
    text_ar     = db.Column(db.Text, nullable=False)
    text_en     = db.Column(db.Text)
    narrator    = db.Column(db.String(200))
    source      = db.Column(db.String(200))
    grading     = db.Column(db.String(50))
    category    = db.Column(db.String(60), index=True)
    is_featured = db.Column(db.Boolean, default=False)
    order_num   = db.Column(db.Integer, default=0)
    created_at  = db.Column(db.DateTime, default=datetime.utcnow)


class Memorial(db.Model):
    __tablename__ = 'memorial'
    id             = db.Column(db.Integer, primary_key=True)
    name           = db.Column(db.String(200), nullable=False)
    note           = db.Column(db.Text)
    preferred_duaa = db.Column(db.Text)
    user_id        = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    session_id     = db.Column(db.String(100))
    is_public      = db.Column(db.Boolean, default=False)
    created_at     = db.Column(db.DateTime, default=datetime.utcnow)


class ChatMessage(db.Model):
    __tablename__ = 'chat_message'
    id           = db.Column(db.Integer, primary_key=True)
    user_id      = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    username     = db.Column(db.String(100), nullable=False)
    message      = db.Column(db.Text, nullable=False)
    message_type = db.Column(db.String(20), default='text')
    room         = db.Column(db.String(50), default='general', index=True)
    is_deleted   = db.Column(db.Boolean, default=False)
    timestamp    = db.Column(db.DateTime, default=datetime.utcnow, index=True)   # ← indexed


class Reciter(db.Model):
    __tablename__ = 'reciter'
    id         = db.Column(db.Integer, primary_key=True)
    name_ar    = db.Column(db.String(100), nullable=False)
    name_en    = db.Column(db.String(100))
    cdn_key    = db.Column(db.String(150))
    style      = db.Column(db.String(30))
    is_active  = db.Column(db.Boolean, default=True)
    order_num  = db.Column(db.Integer, default=0)


# ═══ ADMIN & SYSTEM ═══════════════════════════════════════════════════════════

class AudioHealthCheck(db.Model):
    """
    A single admin-triggered test of a reciter's audio source.
    We keep history (not just a 'last status' column on Reciter) so an admin
    can see whether a source is flaky over time versus a one-off blip.
    """
    __tablename__  = 'audio_health_check'
    id             = db.Column(db.Integer, primary_key=True)
    reciter_id     = db.Column(db.Integer, db.ForeignKey('reciter.id'), nullable=False, index=True)
    surah_num      = db.Column(db.Integer, default=1)
    status         = db.Column(db.String(20))    # healthy | warning | broken
    bitrate        = db.Column(db.Integer)        # bitrate that worked, or null
    url            = db.Column(db.String(300))
    http_status    = db.Column(db.Integer)
    content_type   = db.Column(db.String(100))
    latency_ms     = db.Column(db.Integer)
    failure_reason = db.Column(db.String(250))
    checked_by     = db.Column(db.String(80))
    checked_at     = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    reciter = db.relationship('Reciter', backref=db.backref('health_checks', lazy='dynamic', cascade='all, delete-orphan'))


class Admin(db.Model):
    __tablename__ = 'admin'
    id            = db.Column(db.Integer, primary_key=True)
    username      = db.Column(db.String(80),  unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    email         = db.Column(db.String(120), unique=True)
    role          = db.Column(db.String(20), default='admin')
    created_at    = db.Column(db.DateTime, default=datetime.utcnow)
    last_login    = db.Column(db.DateTime)
    def set_password(self, pw):   self.password_hash = generate_password_hash(pw)
    def check_password(self, pw): return check_password_hash(self.password_hash, pw)


class AuditLog(db.Model):
    __tablename__ = 'audit_log'
    id             = db.Column(db.Integer, primary_key=True)
    admin_username = db.Column(db.String(80))
    action         = db.Column(db.String(200))
    model          = db.Column(db.String(50))
    record_id      = db.Column(db.Integer)
    details        = db.Column(db.Text)
    timestamp      = db.Column(db.DateTime, default=datetime.utcnow)


class FeaturedContent(db.Model):
    __tablename__ = 'featured_content'
    id           = db.Column(db.Integer, primary_key=True)
    content_type = db.Column(db.String(20))
    content_ar   = db.Column(db.Text)
    content_en   = db.Column(db.Text)
    source       = db.Column(db.String(200))
    date         = db.Column(db.Date, default=lambda: datetime.utcnow().date())
    is_active    = db.Column(db.Boolean, default=True)


class SiteSettings(db.Model):
    __tablename__ = 'site_settings'
    id         = db.Column(db.Integer, primary_key=True)
    key        = db.Column(db.String(100), unique=True, nullable=False)
    value      = db.Column(db.Text)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
