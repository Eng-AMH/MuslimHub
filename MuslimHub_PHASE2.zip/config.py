import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    # ── Security ──────────────────────────────────────────────────────────────
    SECRET_KEY = os.environ.get('SECRET_KEY')
    if not SECRET_KEY:
        raise RuntimeError(
            "SECRET_KEY environment variable must be set. "
            "Generate one with: python -c \"import secrets; print(secrets.token_hex(32))\""
        )

    # Session cookies — all three required for proper security
    SESSION_COOKIE_SECURE   = os.environ.get('DEBUG', 'False') != 'True'  # HTTPS only in prod
    SESSION_COOKIE_HTTPONLY = True    # Block JS access
    SESSION_COOKIE_SAMESITE = 'Lax'  # CSRF mitigation
    REMEMBER_COOKIE_SECURE  = os.environ.get('DEBUG', 'False') != 'True'
    REMEMBER_COOKIE_HTTPONLY = True

    # ── Database ──────────────────────────────────────────────────────────────
    SQLALCHEMY_DATABASE_URI      = os.environ.get('DATABASE_URL', 'sqlite:///muslimhub.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # ── App ───────────────────────────────────────────────────────────────────
    DEBUG         = os.environ.get('DEBUG', 'False') == 'True'
    ALLOWED_HOSTS = os.environ.get('ALLOWED_HOSTS', 'localhost').split(',')
    SITE_URL      = os.environ.get('SITE_URL', 'http://localhost:5000')
    SITE_NAME     = os.environ.get('SITE_NAME', 'Muslim Hub')

    # ── External APIs ─────────────────────────────────────────────────────────
    GROQ_API_KEY = os.environ.get('GROQ_API_KEY', '')

    # ── Admin ─────────────────────────────────────────────────────────────────
    ADMIN_USERNAME = os.environ.get('ADMIN_USERNAME', 'admin')
    ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD', 'admin123')
    ADMIN_EMAIL    = os.environ.get('ADMIN_EMAIL', '')

    # ── Email ─────────────────────────────────────────────────────────────────
    EMAIL_HOST_USER    = os.environ.get('EMAIL_HOST_USER', '')
    EMAIL_HOST_PASSWORD = os.environ.get('EMAIL_HOST_PASSWORD', '')
    DEFAULT_FROM_EMAIL  = os.environ.get('DEFAULT_FROM_EMAIL', '')

    # ── CSRF ──────────────────────────────────────────────────────────────────
    WTF_CSRF_ENABLED = True

    # ── Rate limiting ─────────────────────────────────────────────────────────
    RATELIMIT_DEFAULT = "200 per day;50 per hour"
    RATELIMIT_STORAGE_URL = "memory://"
