#!/usr/bin/env python3
from pathlib import Path
import ast, re, subprocess, sys
ROOT=Path(__file__).resolve().parents[1]; errors=[]
for p in ROOT.rglob('*.py'):
    if '__pycache__' in p.parts: continue
    try: ast.parse(p.read_text(encoding='utf-8'))
    except Exception as e: errors.append(f'PY {p}: {e}')
for p in ROOT.rglob('*.js'):
    if 'node_modules' in p.parts: continue
    r=subprocess.run(['node','--check',str(p)],capture_output=True,text=True)
    if r.returncode: errors.append(f'JS {p}: {r.stderr.strip()}')
for p in ROOT.rglob('*.html'):
    s=p.read_text(encoding='utf-8',errors='ignore')
    for i,b in enumerate(re.findall(r'<script(?:[^>]*)>(.*?)</script>',s,re.S|re.I)):
        b=re.sub(r'\{\{.*?\}\}','0',b,flags=re.S); b=re.sub(r'\{%.*?%\}','',b,flags=re.S)
        tmp=ROOT/'tools'/'_inline_check.js'; tmp.write_text(b,encoding='utf-8')
        r=subprocess.run(['node','--check',str(tmp)],capture_output=True,text=True)
        if r.returncode: errors.append(f'INLINE JS {p} block {i}: {r.stderr.strip()}')
        tmp.unlink(missing_ok=True)
    ids=re.findall(r'\bid=["\']([^"\']+)["\']',s)
    dup=sorted({x for x in ids if ids.count(x)>1})
    if dup: errors.append(f'DUP IDS {p}: {dup}')
if errors:
    print('FAIL'); print('\n'.join(errors)); sys.exit(1)
print('PASS: Python syntax, JavaScript syntax, inline JS, and duplicate-ID checks passed.')
