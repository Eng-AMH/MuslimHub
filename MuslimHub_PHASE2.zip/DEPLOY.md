# Muslim Hub — دليل النشر على PythonAnywhere
## Ammar Mostafa Hendam | Artificial Mind Hub

---

## 📁 هيكل الملفات

```
muslimhub/
├── app.py               ← نقطة البداية
├── app_init.py          ← db + socketio
├── config.py            ← الإعدادات
├── models.py            ← نماذج قاعدة البيانات
├── wsgi.py              ← للـ PythonAnywhere
├── requirements.txt
├── .env                 ← متغيرات البيئة (السر)
├── routes/
│   ├── main.py          ← الرئيسية + اللغة + الثيم
│   ├── quran.py         ← القرآن الكريم
│   ├── audio.py         ← القرآن الصوتي
│   ├── adhkar.py        ← الأذكار
│   ├── tasbeeh.py       ← التسبيح
│   ├── duas.py          ← الأدعية
│   ├── memorial.py      ← روح المرحومين
│   ├── prayer.py        ← مواقيت الصلاة
│   ├── chat.py          ← الشات + SocketIO
│   ├── good_deeds.py    ← الأعمال الصالحة
│   ├── admin.py         ← لوحة الإدارة
│   └── api.py           ← API endpoints
├── data/
│   ├── adhkar.json      ← بيانات الأذكار
│   ├── duas.json        ← بيانات الأدعية
│   └── good_deeds.json  ← بيانات الأعمال الصالحة
├── static/
│   ├── css/style.css    ← CSS شامل
│   └── images/
│       ├── logo.svg     ← الشعار
│       └── og-image.svg ← صورة السوشيال ميديا
└── templates/
    ├── base.html        ← القالب الأساسي
    ├── index.html       ← الصفحة الرئيسية
    ├── settings.html
    ├── about.html
    ├── contact.html
    ├── privacy.html
    ├── terms.html
    ├── quran/
    ├── audio/
    ├── adhkar/
    ├── tasbeeh/
    ├── duas/
    ├── memorial/
    ├── prayer/
    ├── chat/
    ├── good_deeds/
    ├── favorites/
    └── admin/
```

---

## 🚀 خطوات النشر على PythonAnywhere

### الخطوة 1 — رفع الملفات
1. افتح **PythonAnywhere Dashboard**
2. اضغط **Files** tab
3. ارفع ملف `muslimhub.zip`
4. افتح **Bash console**:
```bash
cd ~
unzip muslimhub.zip -d muslimhub
cd muslimhub
```

### الخطوة 2 — تثبيت المكتبات
```bash
pip3.10 install --user Flask Flask-SQLAlchemy Flask-SocketIO Flask-WTF python-dotenv Werkzeug simple-websocket
```

### الخطوة 3 — إعداد Web App
1. اذهب لـ **Web** tab في PythonAnywhere
2. اضغط **Add a new web app**
3. اختر domain: `MuslimHub.pythonanywhere.com`
4. اختر **Manual configuration** → Python 3.10
5. في **Source code**: `/home/MuslimHub/muslimhub`
6. في **WSGI configuration file** → اضغط على الرابط وضع:

```python
import sys
import os

project_home = '/home/MuslimHub/muslimhub'
if project_home not in sys.path:
    sys.path.insert(0, project_home)

from app import app as application
```

### الخطوة 4 — Static Files
في **Static files** section:
| URL              | Directory                                     |
|------------------|-----------------------------------------------|
| `/static/`       | `/home/MuslimHub/muslimhub/static/`           |

### الخطوة 5 — ملف البيئة
تأكد أن ملف `.env` موجود في `/home/MuslimHub/muslimhub/.env`

### الخطوة 6 — تشغيل أول مرة
```bash
cd ~/muslimhub
python3.10 -c "from app import app; print('OK')"
```

### الخطوة 7 — اضغط Reload
اضغط **Reload** في Web tab ✅

---

## 🔐 بيانات الإدارة
- **الرابط:** `https://MuslimHub.pythonanywhere.com/admin`
- **المستخدم:** `ammar`
- **كلمة المرور:** `AMH@MuslimHub2025`

---

## 🌐 روابط الموقع
| الصفحة          | الرابط                                               |
|----------------|------------------------------------------------------|
| الرئيسية       | `/`                                                  |
| القرآن         | `/quran/`                                            |
| صوت القرآن     | `/audio/`                                            |
| الأذكار        | `/adhkar/`                                           |
| التسبيح        | `/tasbeeh/`                                          |
| الأدعية        | `/duas/`                                             |
| روح المرحومين  | `/memorial/`                                         |
| مواقيت الصلاة  | `/prayer/`                                           |
| المجلس         | `/chat/`                                             |
| أعمال صالحة    | `/good-deeds/`                                       |
| الإدارة        | `/admin/`                                            |
| API الأدعية    | `/api/duas`                                          |
| API الأذكار    | `/api/adhkar?category=morning`                       |

---

## ✨ المميزات
- ✅ قرآن كريم كامل (114 سورة) عبر alquran.cloud API
- ✅ قرآن صوتي (5 قراء) عبر cdn.islamic.network
- ✅ أذكار الصباح والمساء والنوم وغيرها مع عداد تفاعلي
- ✅ تسبيح رقمي مع progress ring ومؤثر صوتي
- ✅ مكتبة أدعية (13 فئة) مع بحث وتصفية
- ✅ قسم روح المرحومين مع نافذة دعاء تفاعلية
- ✅ مواقيت الصلاة بالموقع الجغرافي + اتجاه القبلة
- ✅ شات جماعي مباشر بـ SocketIO
- ✅ أعمال صالحة يومية مع تتبع الإنجاز
- ✅ لايت مود ودارك مود
- ✅ عربي RTL + إنجليزي LTR
- ✅ لوحة إدارة كاملة (CRUD + سجل عمليات)
- ✅ شعار SVG + صورة OG للسوشيال ميديا
- ✅ Mobile-first responsive

---

## 📞 للدعم
عمار مصطفى هندام | amhartificialmindhub@gmail.com
