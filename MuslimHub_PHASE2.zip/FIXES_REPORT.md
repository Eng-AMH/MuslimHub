# Muslim Hub — Fixes Report

## Fixed

### Quran audio
- Fixed a JavaScript syntax error in `templates/audio/index.html`: duplicated `const progressEl` declaration.
- Reworked `static/js/quran-audio.js` to support adaptive bitrate fallback. The engine now tries available CDN qualities (128, 64, 192, 48, 40, 32 kbps) for the same reciter before switching to the fallback reciter.
- Added explicit handling for browser autoplay-policy rejection so the player no longer gets stuck in a loading/buffering state.
- Added a user-visible message when the engine changes audio quality.
- Kept canonical reciter keys compatible with the Al Quran Cloud surah-audio CDN.

### Qibla / compass
- Fixed the restrictive `Permissions-Policy` header that previously disabled geolocation.
- Enabled `geolocation`, `accelerometer`, `gyroscope`, and `magnetometer` for the same origin.
- Added HTTPS/secure-context detection and clearer permission guidance.
- Prevented repeated sensor-handler registration when the user presses Start more than once.
- Added screen-orientation compensation for portrait/landscape rotation.
- Avoided displaying a fake `0°` heading before a real sensor reading arrives.
- Preserved the local mathematical Qibla bearing calculation to avoid an unnecessary API dependency.

### Prayer times
- Added robust HTTP status checking around AlAdhan requests.
- Changed city lookup from a city-only request with a hard-coded Egypt country to an address request (`City, Country`).
- Added a calculation-method selector instead of silently forcing Egypt's method for every location.
- Kept method 5 as the default because the project is primarily targeted at Egypt, while allowing users elsewhere to select the appropriate method.
- Location-based timing requests also use the selected method.

### Service worker / audio caching
- Bumped service-worker cache versions.
- Stopped intercepting and Cache-API caching Quran MP3 media. Browser media caching and Range requests are now left to the browser, preventing seek/buffering problems and unnecessary large storage consumption.

### Project hygiene / verification
- Removed accidental brace-named directories and generated `__pycache__` folders from the deliverable.
- Added `tools/verify_muslimhub.py` for static regression checks.
- Verification result: Python AST parsing, Node JavaScript syntax checks, inline-template JavaScript checks, and duplicate-ID checks all pass.

## Verification limitation

The sandbox used for this repair does not have Flask or the other project dependencies installed and cannot reach PyPI because outbound DNS/network access is unavailable. Therefore a full Flask request/route integration test could not be run here.

The supplied project includes a working SQLite database and all expected route/template source files; Python syntax compilation succeeds. The final package is ready to run on the target deployment after installing `requirements.txt`.
