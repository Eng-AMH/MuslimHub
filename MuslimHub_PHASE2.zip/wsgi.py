import sys
import os

# Add project to path
project_home = '/home/MuslimHub/muslimhub'
if project_home not in sys.path:
    sys.path.insert(0, project_home)

os.environ['PYTHONPATH'] = project_home

from app import app as application
