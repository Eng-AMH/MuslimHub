/* Muslim Hub — Service Worker v4 | Robust Audio + Static Caching */
const CACHE_STATIC = 'mh-static-v5';
const CACHE_API    = 'mh-api-v5';
const CACHE_FONTS  = 'mh-fonts-v5';
const CACHE_SURAH  = 'mh-surah-v5';
const CACHE_AUDIO  = 'mh-audio-v5';   // NEW: cdn.islamic.network surah MP3s

/*
 * STATIC_SHELL: pure static assets only — no server-rendered HTML.
 * HTML pages use session state and CSRF tokens; caching them breaks auth.
 */
const STATIC_SHELL = [
  '/static/css/style.css',
  '/static/js/quran-audio.js',   // NEW: audio engine is part of the shell
  '/static/images/logo.svg',
  '/static/manifest.json',
  '/static/offline.html',
];

/* ── Install: pre-cache the static shell only ── */
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE_STATIC)
      .then(c => c.addAll(STATIC_SHELL))
      .then(() => self.skipWaiting())
      .catch(err => console.warn('[SW] Install failed:', err))
  );
});

/* ── Activate: prune stale caches ── */
self.addEventListener('activate', e => {
  const KEEP = [CACHE_STATIC, CACHE_API, CACHE_FONTS, CACHE_SURAH, CACHE_AUDIO];
  e.waitUntil(
    caches.keys()
      .then(keys =>
        Promise.all(keys.filter(k => !KEEP.includes(k)).map(k => caches.delete(k)))
      )
      .then(() => self.clients.claim())
  );
});

/* ── Fetch ── */
self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET' || url.protocol === 'chrome-extension:') return;

  /* ── Quran text & prayer APIs — network first, stale cache fallback ── */
  if (url.hostname === 'api.alquran.cloud' || url.hostname === 'api.aladhan.com') {
    e.respondWith(networkFirst(e.request, CACHE_API));
    return;
  }

  /* ── Audio CDN ───────────────────────────────────────────────────────
   * Do not Cache-API intercept media. HTMLMediaElement uses Range requests,
   * and forcing full-file caching can break seeking and consume large storage.
   * The audio engine handles retry/fallback; the browser manages media cache.
   */
  if (url.hostname === 'cdn.islamic.network' &&
      url.pathname.includes('/quran/audio')) {
    return;
  }

  /* ── Google Fonts — cache forever ── */
  if (url.hostname.includes('fonts.gstatic') || url.hostname.includes('fonts.googleapis')) {
    e.respondWith(cacheFirst(e.request, CACHE_FONTS));
    return;
  }

  /* ── Static assets — cache first ── */
  if (url.pathname.startsWith('/static/')) {
    e.respondWith(cacheFirst(e.request, CACHE_STATIC));
    return;
  }

  /* ── HTML pages — network only; branded offline page on failure ── */
  if (e.request.headers.get('Accept')?.includes('text/html')) {
    e.respondWith(networkWithOfflineFallback(e.request));
    return;
  }

  /* ── Everything else — network first ── */
  e.respondWith(networkFirst(e.request, CACHE_STATIC));
});

/* ── Strategies ── */

async function cacheFirst(req, cacheName) {
  const cached = await caches.match(req);
  if (cached) return cached;
  try {
    const res = await fetch(req);
    if (res.ok) {
      const c = await caches.open(cacheName);
      c.put(req, res.clone());
    }
    return res;
  } catch {
    return caches.match('/static/offline.html');
  }
}

async function networkFirst(req, cacheName) {
  try {
    const res = await fetch(req);
    if (res.ok) {
      const c = await caches.open(cacheName);
      c.put(req, res.clone());
    }
    return res;
  } catch {
    const cached = await caches.match(req);
    return cached || caches.match('/static/offline.html');
  }
}

async function networkWithOfflineFallback(req) {
  try {
    return await fetch(req);
  } catch {
    const cached = await caches.match(req);
    if (cached) return cached;
    return caches.match('/static/offline.html');
  }
}

/* ── On-demand Surah text caching (from settings page) ── */
self.addEventListener('message', e => {
  if (e.data?.type === 'CACHE_SURAH') {
    const num  = e.data.surah;
    const apis = [
      `https://api.alquran.cloud/v1/surah/${num}`,
      `https://api.alquran.cloud/v1/surah/${num}/en.sahih`,
    ];
    caches.open(CACHE_SURAH).then(c => {
      apis.forEach(url =>
        fetch(url).then(r => { if (r.ok) c.put(url, r); }).catch(() => {})
      );
    });
  }

  /* Pre-cache a specific surah's audio (called from the player's "save for
   * offline" button). Mirrors the playback engine's own bitrate fallback
   * (static/js/quran-audio.js BITRATES) instead of assuming 128kbps always
   * works — some reciters only publish at other bitrates, and hardcoding
   * 128 here silently cached nothing for those (see AUDIT_REPORT.md). */
  if (e.data?.type === 'CACHE_AUDIO_SURAH') {
    const { surah, cdnKey, bitrate } = e.data;
    const client = e.source;
    if (!surah || !cdnKey) {
      client?.postMessage({ type: 'AUDIO_CACHED', ok: false, surah, reason: 'missing-params' });
      return;
    }
    const ORIGIN = 'https://cdn.islamic.network/quran/audio-surah';
    // If the caller already knows a confirmed-working bitrate (the common
    // case — the player only shows this button once something is actually
    // playing), try only that one. Otherwise fall back through the full list.
    const ALL_BITRATES = [128, 64, 192, 48, 40, 32];
    const candidates = bitrate
      ? [bitrate, ...ALL_BITRATES.filter(b => b !== bitrate)]
      : ALL_BITRATES;
    const tryNext = (i) => {
      if (i >= candidates.length) {
        client?.postMessage({ type: 'AUDIO_CACHED', ok: false, surah, reason: 'all-bitrates-failed' });
        return;
      }
      const url = `${ORIGIN}/${candidates[i]}/${cdnKey}/${surah}.mp3`;
      fetch(url)
        .then(r => {
          if (!r.ok) { tryNext(i + 1); return; }
          caches.open(CACHE_AUDIO).then(c => {
            c.put(url, r);
            client?.postMessage({ type: 'AUDIO_CACHED', ok: true, surah, bitrate: candidates[i] });
          });
        })
        .catch(() => tryNext(i + 1));
    };
    tryNext(0);
  }

  if (e.data?.type === 'GET_CACHE_SIZE') {
    getCacheSize().then(size => e.source.postMessage({ type: 'CACHE_SIZE', size }));
  }

  /* Evict audio cache on demand (e.g. from Settings > clear cache) */
  if (e.data?.type === 'CLEAR_AUDIO_CACHE') {
    caches.delete(CACHE_AUDIO).then(() =>
      e.source?.postMessage({ type: 'AUDIO_CACHE_CLEARED' })
    );
  }
});

async function getCacheSize() {
  let total = 0;
  for (const k of await caches.keys()) {
    const c    = await caches.open(k);
    const reqs = await c.keys();
    for (const r of reqs) {
      const res = await c.match(r);
      const buf = await res.arrayBuffer().catch(() => null);
      if (buf) total += buf.byteLength;
    }
  }
  return total;
}