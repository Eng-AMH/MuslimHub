/**
 * quran-audio.js — MuslimHub Shared Audio Engine  v1.0
 *
 * Single source of truth for:
 *   - CDN URL building + validation
 *   - Playback state machine (idle → loading → buffering → playing → paused → failed → recovering)
 *   - Retry with exponential backoff (max 2 retries)
 *   - Automatic fallback to a known-good reciter when all retries fail
 *   - User preference persistence (localStorage)
 *   - Custom event bus so multiple UI layers stay in sync
 *
 * Usage
 * ─────
 *   const engine = new QuranAudioEngine(audioElement);
 *   engine.on('statechange', ({ state, prev }) => updateUI(state));
 *   engine.on('fallback',    ({ original, fallback }) => showFallbackNotice());
 *   engine.on('error',       ({ reason }) => showError(reason));
 *   engine.on('progress',    ({ currentTime, duration, percent }) => updateBar());
 *   engine.on('ended',       ({ surah }) => handleEnded());
 *
 *   engine.load(surahNum, cdnKey, reciterName);   // autoPlay defaults to true
 *   engine.pause();
 *   engine.togglePlay();
 *   engine.seek(percent);         // 0–100
 *   engine.setSpeed(1.5);
 *   engine.setLoop(true);
 *   engine.destroy();             // clean up listeners when removing the element
 *
 * Static helpers (no instance needed)
 * ────────────────────────────────────
 *   QuranAudioEngine.buildUrl(surahNum, cdnKey)   → URL string | null
 *   QuranAudioEngine.isValidCdnKey(key)           → boolean
 *   QuranAudioEngine.loadReciterPreference()      → cdnKey string | null
 *   QuranAudioEngine.loadLastPlayed()             → { num, cdn, name } | null
 *   QuranAudioEngine.FALLBACK_CDN                 → string
 */

;(function (global) {
  'use strict';

  /* ── CDN ─────────────────────────────────────────────────────────────────── */

  var CDN_ORIGIN   = 'https://cdn.islamic.network/quran/audio-surah';
  // Not every edition is published at 128kbps. Try the requested quality, then
  // the common lower bitrates before declaring the edition unavailable.
  var BITRATES     = [128, 64, 192, 48, 40, 32];

  /**
   * Safe reciter guaranteed to exist on cdn.islamic.network.
   *
   * CDN KEY FORMAT — CRITICAL:
   *   cdn.islamic.network uses the SAME `ar.IDENTIFIER` format for BOTH
   *   ayah-level (/quran/audio/) and surah-level (/quran/audio-surah/) audio.
   *
   *   Correct examples:
   *     ar.alafasy   ar.abdurrahmaansudais   ar.mahermuaiqly
   *     ar.husary    ar.minshawi             ar.saadalghamdi
   *     ar.shaatree  ar.abdulbasitmurattal   ar.husarymujawwad
   *
   *   WRONG (old mp3quran.net format — does NOT exist on this CDN):
   *     Alafasy_128kbps   Abdurrahmaan_As-Sudais_192kbps   Husary_128kbps
   *
   * Source: https://cdn.islamic.network/quran/info/by-surah/info.json
   *         https://alquran.cloud/cdn
   */
  var FALLBACK_CDN = 'ar.alafasy';

  /**
   * CDN key validation pattern.
   * Matches: ar.alafasy  ar.husarymujawwad  ar.abdurrashidsufi.soosi
   * Rejects: Alafasy_128kbps (old format), spaces, raw URLs, empty strings.
   */
  var CDN_KEY_RE = /^[a-zA-Z][a-zA-Z0-9._-]{1,99}$/;

  /* ── STATES ──────────────────────────────────────────────────────────────── */

  var S = {
    IDLE:       'idle',       // nothing loaded yet
    LOADING:    'loading',    // src set, waiting for browser metadata
    BUFFERING:  'buffering',  // metadata arrived, waiting for audio data
    PLAYING:    'playing',    // actively playing
    PAUSED:     'paused',     // intentionally paused by user
    FAILED:     'failed',     // all retries and fallback exhausted
    RECOVERING: 'recovering'  // about to retry or switch reciter
  };

  /* ── RETRY SCHEDULE ─────────────────────────────────────────────────────── */
  var RETRY_DELAYS_MS = [1500, 4000];   // try original CDN up to 2 more times

  /* ── STORAGE KEYS ───────────────────────────────────────────────────────── */
  var PREF_RECITER = 'mh_audio_reciter';
  var PREF_LAST    = 'mh_audio_last';

  /* ══════════════════════════════════════════════════════════════════════════
   * STATIC HELPERS
   * ══════════════════════════════════════════════════════════════════════════ */

  function buildUrl(surahNum, cdnKey, bitrate) {
    var n = Number(surahNum);
    if (!n || n < 1 || n > 114) return null;
    var key = (cdnKey || '').trim();
    if (!CDN_KEY_RE.test(key)) return null;
    var br = Number(bitrate) || 128;
    if (BITRATES.indexOf(br) === -1) return null;
    return CDN_ORIGIN + '/' + br + '/' + key + '/' + n + '.mp3';
  }

  function isValidCdnKey(key) {
    return !!key && CDN_KEY_RE.test((key + '').trim());
  }

  function _storeSafe(k, v) {
    try { localStorage.setItem(k, v); } catch (_) {}
  }

  function _loadSafe(k) {
    try { return localStorage.getItem(k); } catch (_) { return null; }
  }

  function savePreference(cdnKey) {
    _storeSafe(PREF_RECITER, cdnKey);
  }

  function loadReciterPreference() {
    return _loadSafe(PREF_RECITER);
  }

  function saveLastPlayed(surahNum, cdnKey, name) {
    _storeSafe(PREF_LAST, JSON.stringify({
      num:  surahNum,
      cdn:  cdnKey,
      name: name || String(surahNum)
    }));
  }

  function loadLastPlayed() {
    try { return JSON.parse(_loadSafe(PREF_LAST) || 'null'); } catch (_) { return null; }
  }

  /* ══════════════════════════════════════════════════════════════════════════
   * ENGINE CLASS
   * ══════════════════════════════════════════════════════════════════════════ */

  function QuranAudioEngine(audioEl) {
    if (!(audioEl instanceof HTMLAudioElement)) {
      throw new Error('QuranAudioEngine: first argument must be an <audio> element');
    }

    this._el           = audioEl;
    this._state        = S.IDLE;
    this._surah        = null;
    this._cdnKey       = null;
    this._cdnKeyOrig   = null;   // original key, so we know when fallback is in use
    this._reciterName  = '';
    this._retryCount   = 0;
    this._retryTimer   = null;
    this._pendingPlay  = false;  // intent to play (set before audio is ready)
    this._usingFallback = false;
    this._bitrateIndex   = 0;
    this._listeners    = {};

    this._bindEvents();
  }

  /* ── Attach static helpers to constructor for convenience ── */
  QuranAudioEngine.S                   = S;
  QuranAudioEngine.buildUrl            = buildUrl;
  QuranAudioEngine.isValidCdnKey       = isValidCdnKey;
  QuranAudioEngine.savePreference      = savePreference;
  QuranAudioEngine.loadReciterPreference = loadReciterPreference;
  QuranAudioEngine.saveLastPlayed      = saveLastPlayed;
  QuranAudioEngine.loadLastPlayed      = loadLastPlayed;
  QuranAudioEngine.FALLBACK_CDN        = FALLBACK_CDN;
  QuranAudioEngine.CDN_KEY_RE          = CDN_KEY_RE;
  QuranAudioEngine.BITRATES             = BITRATES;

  var proto = QuranAudioEngine.prototype;

  /* ── Public read ── */

  proto.getState        = function () { return this._state; };
  proto.getSurah        = function () { return this._surah; };
  proto.getCdnKey       = function () { return this._cdnKey; };
  proto.isPlaying       = function () { return this._state === S.PLAYING; };
  proto.isUsingFallback = function () { return this._usingFallback; };

  /**
   * The bitrate that actually worked for the current source, or null if
   * nothing has successfully loaded yet. Used by "save for offline" UI so it
   * caches the bitrate that's confirmed to work rather than re-guessing.
   */
  proto.getCurrentBitrate = function () {
    var loaded = this._state === S.PLAYING || this._state === S.PAUSED || this._state === S.BUFFERING;
    return loaded ? (BITRATES[this._bitrateIndex] || null) : null;
  };

  /* ── Core API ── */

  /**
   * Load a surah with a given reciter.
   * @param {number}  surahNum     1 – 114
   * @param {string}  cdnKey       CDN edition key  (e.g. "Alafasy_128kbps")
   * @param {string}  reciterName  Human-readable name shown in UI
   * @param {boolean} [autoPlay=true]
   */
  proto.load = function (surahNum, cdnKey, reciterName, autoPlay) {
    autoPlay = (autoPlay !== false);

    var n   = Number(surahNum);
    var key = (cdnKey || '').trim();

    if (!n || n < 1 || n > 114) {
      this._fail('invalid-surah');
      return;
    }
    if (!isValidCdnKey(key)) {
      this._fail('invalid-cdn-key', { key: key });
      return;
    }

    this._clearRetry();
    this._surah        = n;
    this._cdnKey       = key;
    this._cdnKeyOrig   = key;
    this._reciterName  = reciterName || key;
    this._retryCount   = 0;
    this._usingFallback = false;
    this._bitrateIndex   = 0;
    this._pendingPlay  = autoPlay;

    this._doLoad(key);
  };

  proto.play = function () {
    var st = this._state;
    if (st === S.PLAYING) return;

    if (st === S.PAUSED || st === S.BUFFERING) {
      this._pendingPlay = true;
      var self = this;
      this._attemptPlay();
      return;
    }
    if (st === S.LOADING || st === S.RECOVERING) {
      this._pendingPlay = true; // will auto-play when ready
      return;
    }
    // IDLE or FAILED — nothing loaded, cannot play
    this._emit('error', { reason: 'nothing-loaded' });
  };

  proto.pause = function () {
    this._pendingPlay = false;
    if (!this._el.paused) this._el.pause();
    var st = this._state;
    if (st === S.PLAYING || st === S.BUFFERING) {
      this._setState(S.PAUSED);
    }
  };

  proto.togglePlay = function () {
    if (this._state === S.PLAYING) this.pause();
    else this.play();
  };

  proto.seek = function (percent) {
    var d = this._el.duration;
    if (d && isFinite(d)) {
      this._el.currentTime = (percent / 100) * d;
    }
  };

  proto.setSpeed = function (rate) {
    this._el.playbackRate = Number(rate) || 1;
  };

  proto.setLoop = function (v) {
    this._el.loop = !!v;
  };

  proto._attemptPlay = function () {
    var self = this;
    return this._el.play().then(function () {
      self._setState(S.PLAYING);
    }).catch(function (err) {
      // Browser autoplay policies can reject play() without firing media 'error'.
      if (err && err.name === 'NotAllowedError') {
        self._pendingPlay = false;
        self._setState(S.PAUSED);
        self._emit('error', { reason: 'autoplay-blocked' });
      }
    });
  };

  /* ── Event bus ── */

  /**
   * Register a listener.
   * Events: statechange, error, fallback, progress, ended
   */
  proto.on = function (event, fn) {
    if (!this._listeners[event]) this._listeners[event] = [];
    this._listeners[event].push(fn);
    return this; // chainable
  };

  proto.off = function (event, fn) {
    if (!this._listeners[event]) return;
    this._listeners[event] = this._listeners[event].filter(function (f) {
      return f !== fn;
    });
  };

  proto.destroy = function () {
    this._clearRetry();
    try { this._el.pause(); } catch (_) {}
    this._el.removeEventListener('canplay',        this._h_canplay);
    this._el.removeEventListener('canplaythrough', this._h_canplaythrough);
    this._el.removeEventListener('waiting',        this._h_waiting);
    this._el.removeEventListener('playing',        this._h_playing);
    this._el.removeEventListener('pause',          this._h_pause);
    this._el.removeEventListener('ended',          this._h_ended);
    this._el.removeEventListener('error',          this._h_error);
    this._el.removeEventListener('timeupdate',     this._h_timeupdate);
    this._listeners = {};
  };

  /* ── Private ── */

  proto._doLoad = function (cdnKey) {
    var bitrate = BITRATES[this._bitrateIndex] || 128;
    var url = buildUrl(this._surah, cdnKey, bitrate);
    if (!url) {
      this._fail('bad-url', { cdnKey: cdnKey });
      return;
    }
    this._setState(S.LOADING);
    try {
      this._el.pause();
      this._el.src = url;
      this._el.load();
      // autoPlay proceeds from _h_canplay once the browser has enough info
    } catch (e) {
      this._fail('load-exception', { message: e.message });
    }
  };

  proto._bindEvents = function () {
    var self = this;

    this._h_canplay = function () {
      if (self._state === S.LOADING) {
        self._setState(S.BUFFERING);
        if (self._pendingPlay) {
          self._attemptPlay();
        }
      }
    };

    this._h_canplaythrough = function () {
      // More data is available; if we were trying to play and canplay didn't start it, try again
      if (self._state === S.BUFFERING && self._pendingPlay) {
        self._attemptPlay();
      }
    };

    this._h_playing = function () {
      // This fires when playback actually starts / resumes
      self._retryCount  = 0;
      self._bitrateIndex = 0;  // reset retry counter on success
      self._pendingPlay = false;
      self._setState(S.PLAYING);
      // Persist successful playback
      saveLastPlayed(self._surah, self._cdnKey, self._reciterName);
      savePreference(self._cdnKey);
    };

    this._h_waiting = function () {
      // Stalled mid-playback (network slow, seeking ahead of buffer)
      if (self._state === S.PLAYING) {
        self._setState(S.BUFFERING);
      }
    };

    this._h_pause = function () {
      // Only reflect externally-triggered pauses.
      // Avoid false pause events from load() or src change.
      var st = self._state;
      if (!self._pendingPlay && st !== S.LOADING && st !== S.RECOVERING) {
        self._setState(S.PAUSED);
      }
    };

    this._h_ended = function () {
      self._pendingPlay = false;
      self._setState(S.IDLE);
      self._emit('ended', { surah: self._surah });
    };

    this._h_error = function () {
      if (self._state === S.FAILED) return;  // already handled

      var code = self._el.error ? self._el.error.code : -1;
      // code 2 = MEDIA_ERR_NETWORK, code 4 = MEDIA_ERR_SRC_NOT_SUPPORTED

      var nextBitrate = self._bitrateIndex + 1 < BITRATES.length;
      var canRetry     = self._retryCount < RETRY_DELAYS_MS.length;
      var canFallback  = !self._usingFallback && self._cdnKeyOrig !== FALLBACK_CDN;

      // First try another published bitrate for the SAME reciter. This fixes
      // editions that exist at 64kbps but not 128kbps.
      if (nextBitrate) {
        self._bitrateIndex++;
        self._retryCount = 0;
        self._setState(S.RECOVERING);
        self._emit('error', {
          reason: 'retrying-bitrate',
          bitrate: BITRATES[self._bitrateIndex],
          code: code
        });
        self._retryTimer = setTimeout(function () {
          self._doLoad(self._cdnKey);
        }, 350);

      } else if (canRetry) {
        var delay = RETRY_DELAYS_MS[self._retryCount];
        self._retryCount++;
        self._setState(S.RECOVERING);
        self._emit('error', { reason: 'retrying', attempt: self._retryCount, code: code });
        self._retryTimer = setTimeout(function () {
          self._doLoad(self._cdnKey);
        }, delay);

      } else if (canFallback) {
        // All retries failed on chosen reciter → switch to safe fallback
        self._usingFallback = true;
        self._cdnKey        = FALLBACK_CDN;
        self._retryCount    = 0;
        self._bitrateIndex  = 0;
        self._setState(S.RECOVERING);
        self._emit('fallback', {
          original: self._cdnKeyOrig,
          fallback: FALLBACK_CDN,
          surah:    self._surah
        });
        self._retryTimer = setTimeout(function () {
          self._doLoad(FALLBACK_CDN);
        }, 600);

      } else {
        // Even fallback failed — give up honestly
        self._pendingPlay = false;
        self._fail('fatal', { code: code, surah: self._surah, cdnKey: self._cdnKey });
      }
    };

    this._h_timeupdate = function () {
      var d = self._el.duration;
      if (!d || !isFinite(d)) return;
      self._emit('progress', {
        currentTime: self._el.currentTime,
        duration:    d,
        percent:     (self._el.currentTime / d) * 100
      });
    };

    this._el.addEventListener('canplay',        this._h_canplay);
    this._el.addEventListener('canplaythrough', this._h_canplaythrough);
    this._el.addEventListener('waiting',        this._h_waiting);
    this._el.addEventListener('playing',        this._h_playing);
    this._el.addEventListener('pause',          this._h_pause);
    this._el.addEventListener('ended',          this._h_ended);
    this._el.addEventListener('error',          this._h_error);
    this._el.addEventListener('timeupdate',     this._h_timeupdate);
  };

  proto._setState = function (newState) {
    if (newState === this._state) return;
    var prev     = this._state;
    this._state  = newState;
    this._emit('statechange', { state: newState, prev: prev });
  };

  proto._fail = function (reason, extra) {
    this._pendingPlay = false;
    this._setState(S.FAILED);
    var payload = Object.assign({ reason: reason }, extra || {});
    this._emit('error', payload);
  };

  proto._clearRetry = function () {
    if (this._retryTimer) {
      clearTimeout(this._retryTimer);
      this._retryTimer = null;
    }
  };

  proto._emit = function (event, data) {
    var fns = this._listeners[event] || [];
    for (var i = 0; i < fns.length; i++) {
      try { fns[i](data); } catch (_) {}
    }
  };

  /* ── Export ── */
  global.QuranAudioEngine = QuranAudioEngine;

}(window));